SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_card_number_pools (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 pool_code VARCHAR(20) NOT NULL,
 name_ar VARCHAR(120) NOT NULL,
 name_en VARCHAR(120) NOT NULL,
 prefix VARCHAR(5) NOT NULL,
 token_length TINYINT UNSIGNED NOT NULL DEFAULT 6,
 is_exclusive TINYINT(1) NOT NULL DEFAULT 1,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_teps_card_pool_code(pool_code), UNIQUE KEY uq_teps_card_pool_prefix(prefix)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_card_number_reservations (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 pool_id INT UNSIGNED NOT NULL,
 card_number VARCHAR(32) NOT NULL,
 card_id BIGINT UNSIGNED NULL,
 reserved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_teps_card_reserved_number(card_number),
 KEY idx_teps_card_res_pool(pool_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_user_account_links (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 provider ENUM('email','whatsapp','facebook') NOT NULL,
 provider_subject VARCHAR(255) NULL,
 destination VARCHAR(255) NULL,
 verified_at TIMESTAMP NULL,
 last_used_at TIMESTAMP NULL,
 status ENUM('pending','verified','revoked') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_teps_account_provider_subject(provider,provider_subject),
 KEY idx_teps_account_link_user(user_id), KEY idx_teps_account_link_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_user_localization (
 user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 language_code CHAR(2) NOT NULL DEFAULT 'ar',
 country_code CHAR(2) NULL,
 country_name_ar VARCHAR(100) NULL,
 country_name_en VARCHAR(100) NULL,
 country_flag VARCHAR(16) NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_ai_content_settings (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 category_code VARCHAR(60) NOT NULL,
 enabled TINYINT(1) NOT NULL DEFAULT 1,
 daily_count INT UNSIGNED NOT NULL DEFAULT 1,
 weekly_count INT UNSIGNED NOT NULL DEFAULT 7,
 monthly_count INT UNSIGNED NOT NULL DEFAULT 30,
 posting_times_json TEXT NULL,
 audience VARCHAR(80) NOT NULL DEFAULT 'all',
 language_mode ENUM('auto','ar','en','bilingual') NOT NULL DEFAULT 'auto',
 needs_image TINYINT(1) NOT NULL DEFAULT 0,
 ai_image TINYINT(1) NOT NULL DEFAULT 0,
 approval_required TINYINT(1) NOT NULL DEFAULT 1,
 auto_publish TINYINT(1) NOT NULL DEFAULT 0,
 safety_level ENUM('normal','review','strict') NOT NULL DEFAULT 'normal',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_teps_ai_content_category(category_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_ai_content_queue (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 category_code VARCHAR(60) NOT NULL,
 title_ar VARCHAR(255) NULL, title_en VARCHAR(255) NULL,
 body_ar LONGTEXT NULL, body_en LONGTEXT NULL,
 image_prompt TEXT NULL, image_url VARCHAR(500) NULL,
 audience VARCHAR(80) NOT NULL DEFAULT 'all',
 status ENUM('draft','pending_review','approved','scheduled','published','rejected','failed') NOT NULL DEFAULT 'draft',
 scheduled_at DATETIME NULL, published_at DATETIME NULL,
 requires_human_review TINYINT(1) NOT NULL DEFAULT 1,
 source_hash CHAR(64) NULL,
 ai_run_id VARCHAR(80) NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_teps_ai_queue_status_time(status,scheduled_at), KEY idx_teps_ai_queue_hash(source_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_ai_content_runs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 run_key VARCHAR(100) NOT NULL,
 category_code VARCHAR(60) NULL,
 provider VARCHAR(80) NULL,
 model VARCHAR(120) NULL,
 status ENUM('started','completed','failed') NOT NULL DEFAULT 'started',
 input_json LONGTEXT NULL,
 output_json LONGTEXT NULL,
 error_message TEXT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_teps_ai_run_key(run_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teps_broadcast_questions (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 author_id BIGINT UNSIGNED NOT NULL,
 source_language CHAR(2) NOT NULL DEFAULT 'ar',
 question_ar TEXT NOT NULL,
 question_en TEXT NOT NULL,
 status ENUM('draft','published','closed') NOT NULL DEFAULT 'published',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_teps_question_status(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO teps_card_number_pools(pool_code,name_ar,name_en,prefix,token_length,is_exclusive) VALUES
('ADMIN','الإدارة','Administration','AD',6,1),
('SUPERVISOR','مشرفو المنصة','Platform Supervisors','SV',6,1),
('STAFF','العاملون','Staff','ST',6,1),
('TECHNICAL','الفنيون','Technical','TC',6,1),
('SPECIALIST','المختصون','Specialists','SP',6,1),
('GENERAL','عضوية عادية','General','BS',6,0),
('SILVER','العضوية الفضية','Silver','SL',6,0),
('GOLD','العضوية الذهبية','Gold','GD',6,0),
('PREMIUM','العضوية المميزة','Premium','PR',6,0),
('JOB_SEEKER','باحثو العمل','Job Seekers','JS',6,0),
('EMPLOYER','أصحاب العمل','Employers','EM',6,0)
ON DUPLICATE KEY UPDATE name_ar=VALUES(name_ar),name_en=VALUES(name_en),prefix=VALUES(prefix),token_length=VALUES(token_length),is_active=1;

INSERT INTO teps_ai_content_settings(category_code,enabled,daily_count,weekly_count,monthly_count,posting_times_json,audience,language_mode,needs_image,ai_image,approval_required,auto_publish,safety_level) VALUES
('culture',1,1,7,30,'["09:00"]','all','bilingual',1,1,1,0,'normal'),
('science',1,1,7,30,'["11:00"]','all','bilingual',1,1,1,0,'normal'),
('medical_awareness',1,1,7,30,'["13:00"]','all','bilingual',1,1,1,0,'strict'),
('engineering',1,1,7,30,'["15:00"]','all','bilingual',1,1,1,0,'normal'),
('technical',1,1,7,30,'["17:00"]','all','bilingual',1,1,1,0,'normal'),
('employment',1,1,7,30,'["19:00"]','job_seekers','bilingual',1,1,1,0,'normal'),
('public_services',1,1,7,30,'["20:00"]','all','bilingual',1,0,1,0,'normal'),
('education',1,1,7,30,'["21:00"]','all','bilingual',1,1,1,0,'normal')
ON DUPLICATE KEY UPDATE updated_at=CURRENT_TIMESTAMP;

-- Non-destructive backfill from existing profiles.language where possible.
INSERT INTO teps_user_localization(user_id,language_code)
SELECT p.user_id, CASE WHEN p.language IN ('ar','en') THEN p.language ELSE 'ar' END FROM profiles p
ON DUPLICATE KEY UPDATE language_code=VALUES(language_code);
