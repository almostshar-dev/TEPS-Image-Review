<?php
declare(strict_types=1);
require_once __DIR__.'/../backend/src/env.php';
require_once __DIR__.'/../backend/src/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
try {
    $count=(int)$db->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
} catch(Throwable $e) { http_response_code(500); echo '<h1>تعذر الاتصال بقاعدة البيانات</h1>'; exit; }
if($count>0){ http_response_code(403); echo '<h1>تم إغلاق إعداد المدير الأول</h1><p>يوجد حساب مدير بالفعل. استخدم صفحة تسجيل الدخول للوصول إلى لوحة التحكم.</p>'; exit; }
$error=''; $ok='';
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
    $key=trim((string)($_POST['install_key']??''));
    $expected=(string)(tamim_env('TAMIM_INSTALL_KEY','')??'');
    $name=trim((string)($_POST['full_name']??'')); $email=trim((string)($_POST['email']??'')); $phone=trim((string)($_POST['phone']??'')); $pass=(string)($_POST['password']??'');
    if($expected===''||!hash_equals($expected,$key)) $error='مفتاح التثبيت غير صحيح.';
    elseif($name===''||(!$email&&!$phone)||strlen($pass)<10) $error='أدخل الاسم والبريد أو الهاتف وكلمة مرور من 10 أحرف على الأقل.';
    else { try {
        // Compatibility tables for installations whose MySQL database was imported without the optional admin/terms tables.
        $db->exec("CREATE TABLE IF NOT EXISTS admin_2fa (user_id INT PRIMARY KEY, enabled TINYINT NOT NULL DEFAULT 0)");
        $db->beginTransaction();
        $st=$db->prepare('INSERT INTO users(phone,email,password_hash,role,status,phone_serial) VALUES(?,?,?,?,?,?)');
        $st->execute([$phone?:null,$email?:null,password_hash($pass,PASSWORD_DEFAULT),'admin','active','TEPS-ADMIN-'.strtoupper(bin2hex(random_bytes(4)))]);
        $uid=(int)$db->lastInsertId();
        $db->prepare('INSERT INTO profiles(user_id,full_name,language,verified_status,gender,nationality,primary_phone) VALUES(?,?,?,?,?,?,?)')->execute([$uid,$name,'ar','approved',null,null,$phone?:null]);
        $db->commit(); $ok='تم إنشاء حساب المدير بنجاح. يمكنك الآن تسجيل الدخول إلى لوحة التحكم. احذف ملف first-setup.php من الخادم بعد إتمام الدخول.';
    } catch(Throwable $e){ if($db->inTransaction())$db->rollBack(); $error='تعذر إنشاء الحساب. تأكد أن البريد أو الهاتف غير مستخدم.'; }
    }
}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>إعداد مدير منصة التميم</title><style>body{font-family:Arial,sans-serif;background:#eef5fb;margin:0;padding:30px;color:#123}main{max-width:520px;margin:auto;background:#fff;padding:28px;border-radius:18px;box-shadow:0 8px 30px #0001}h1{color:#073b73}label{display:block;margin:14px 0 6px;font-weight:700}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #ccd8e5;border-radius:10px}button{margin-top:20px;width:100%;padding:13px;border:0;border-radius:10px;background:#0868d8;color:#fff;font-size:16px;font-weight:700}.err{background:#fee;color:#a00;padding:10px;border-radius:10px}.ok{background:#efffee;color:#176b1d;padding:10px;border-radius:10px}</style></head><body><main><h1>إعداد المدير الأول — منصة التميم</h1><p>هذه الصفحة تعمل فقط عندما لا يوجد أي حساب مدير. وجود حسابات مستخدمين عادية لا يمنع إنشاء المدير الأول.</p><?php if($error):?><div class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif;?><?php if($ok):?><div class="ok"><?=htmlspecialchars($ok,ENT_QUOTES,'UTF-8')?></div><?php else:?><form method="post"><label>مفتاح التثبيت</label><input name="install_key" required><label>اسم المدير</label><input name="full_name" required><label>البريد الإلكتروني</label><input type="email" name="email"><label>رقم الهاتف</label><input name="phone"><label>كلمة المرور</label><input type="password" name="password" minlength="10" required><button>إنشاء حساب المدير</button></form><?php endif;?></main></body></html>
