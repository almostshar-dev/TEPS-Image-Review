(function(){
 const script=document.currentScript;
 const base=(script&&script.src.includes('/admin/'))?script.src.split('/admin/')[0]:(location.origin||'');
 const menu=[
  ['⌂','لوحة المعلومات','/admin/analytics.html'],
  ['📅','الحجوزات والطلبات','/admin/unified-platform.html#bookings'],
  ['🧾','الفواتير والمالية','/frontend/admin/finance.html'],
  ['👥','المستخدمون','/admin/platform-management.html#users'],
  ['👨‍💼','الموظفون والمشرفون','/admin/platform-management.html#users'],
  ['🛠️','الخدمات','/admin/platform-management.html#services'],
  ['🏷️','التصنيفات','/admin/platform-management.html#services'],
  ['🏷️','تصنيفات الخدمات','/admin/platform-management.html#services'],
  ['🏢','الشركات','/admin/platform-management.html#companies'],
  ['🏛️','المؤسسات والجهات','/admin/platform-management.html#institutions'],
  ['🏥','المنشآت والمراكز','/admin/platform-management.html#facilities'],
  ['💼','الوظائف','/admin/external-jobs.html'],
  ['📋','طلبات التوظيف','/admin/unified-platform.html#applications'],
  ['📢','الإعلانات والعروض','/admin/homepage.html'],
  ['📦','الباقات والاشتراكات','/admin/rewards.html'],
  ['🎁','نظام الولاء والمكافآت','/admin/rewards.html'],
  ['⭐','التقييمات','/admin/unified-platform.html#reviews'],
  ['🔔','الإشعارات','/admin/unified-platform.html#notifications'],
  ['💬','صندوق الوارد والدردشة','/frontend/messages/index.html'],
  ['📊','التقارير والتحليلات','/admin/analytics.html'],
  ['🇾🇪','المحافظات والمديريات','/admin/yemen-reference.html'],
  ['🗃️','البيانات والاستيراد والتصدير','/admin/data-center.html'],
  ['🔌','التكاملات وواجهات API','/admin/integrations.html'],
  ['🔐','الصلاحيات والأمان','/admin/system-settings.html#security'],
  ['⚙️','الإعدادات','/admin/system-settings.html'],
  ['👤','حسابات المديرين','/admin/admin-accounts.html']
 ];
 const aside=document.createElement('aside');aside.className='teps-admin-sidebar';
 aside.innerHTML='<div class="teps-admin-head"><img src="'+base+'/frontend/assets/logo.png" alt="منصة التميم"><div><b>منصة التميم</b><small>لوحة الإدارة</small></div><button type="button" aria-label="إغلاق القائمة">‹</button></div><div class="teps-admin-search"><input aria-label="بحث في الإدارة" placeholder="بحث في الإدارة..."></div><nav></nav><div class="teps-admin-foot"><div class="teps-admin-user"><div class="avatar">م</div><div><b id="tepsAdminName">مدير المنصة</b><small>حساب مدير النظام</small></div></div><a class="teps-admin-logout" href="javascript:void(0)">🚪 تسجيل الخروج</a></div>';
 const overlay=document.createElement('div');overlay.className='teps-admin-overlay';
 const nav=aside.querySelector('nav');
 menu.forEach(([i,l,h])=>{const a=document.createElement('a');a.href=base+h;a.innerHTML='<span>'+i+'</span><b>'+l+'</b>';nav.appendChild(a)});
 document.body.append(overlay,aside);
 const toggle=document.createElement('button');toggle.type='button';toggle.className='teps-admin-toggle';toggle.setAttribute('aria-label','إظهار وإخفاء القائمة');toggle.innerHTML='›';document.body.append(toggle);
 function user(){try{return JSON.parse(localStorage.getItem('tamim_user')||'{}')}catch(e){return {}}}
 const u=user();aside.querySelector('#tepsAdminName').textContent=u.full_name||u.phone||'مدير المنصة';
 if(!document.querySelector('.admin-universal-welcome') && !document.querySelector('.welcome')){const h=new Date().getHours(),g=h<12?'صباح الخير':h<18?'مساء الخير':'مساء الخير';const w=document.createElement('div');w.className='admin-universal-welcome';w.innerHTML='<div><small>منصة التميم • لوحة الإدارة</small><strong>'+g+'، '+(u.full_name||u.phone||'مدير المنصة')+'</strong></div><span>إدارة النظام</span>';document.body.insertBefore(w,document.body.firstChild)}
 const current=location.pathname.replace(/\\/g,'/');nav.querySelectorAll('a').forEach(a=>{const p=new URL(a.href,location.href).pathname;if(p===current)a.classList.add('active')});
 function set(collapsed){aside.classList.toggle('collapsed',collapsed);toggle.classList.toggle('active',!collapsed);toggle.innerHTML=collapsed?'›':'‹';overlay.classList.toggle('show',!collapsed&&innerWidth<=1000);localStorage.setItem('teps_admin_sidebar',collapsed?'1':'0')}
 const saved=localStorage.getItem('teps_admin_sidebar');set(saved===null?innerWidth<=1000:saved==='1');
 toggle.onclick=()=>set(!aside.classList.contains('collapsed'));aside.querySelector('.teps-admin-head button').onclick=()=>set(true);overlay.onclick=()=>set(true);
 aside.querySelector('.teps-admin-search input').oninput=e=>{const q=e.target.value.trim().toLowerCase();nav.querySelectorAll('a').forEach(a=>a.style.display=!q||a.textContent.toLowerCase().includes(q)?'flex':'none')};
 aside.querySelector('.teps-admin-logout').onclick=async()=>{try{await fetch(base+'/api/logout',{method:'POST',headers:{Authorization:'Bearer '+(localStorage.getItem('tamim_token')||'')}})}catch(e){}localStorage.removeItem('tamim_token');localStorage.removeItem('tamim_user');location.href=base+'/frontend/index.html'};
 addEventListener('resize',()=>{if(innerWidth>1000)overlay.classList.remove('show');else overlay.classList.toggle('show',!aside.classList.contains('collapsed'))});
})();
