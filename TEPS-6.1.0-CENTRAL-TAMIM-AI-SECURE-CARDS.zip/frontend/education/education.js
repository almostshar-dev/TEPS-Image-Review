const educationMount=document.getElementById('educationMount');
if(educationMount){
 fetch('education/index.html').then(r=>r.text()).then(html=>{educationMount.innerHTML=html;loadEducation();});
}
function loadEducation(){
 const list=document.getElementById('educationList'); if(!list)return;
 const params=new URLSearchParams(); const t=document.getElementById('educationType').value,g=document.getElementById('educationGov').value,q=document.getElementById('educationQ').value;
 if(t)params.set('type',t); if(g)params.set('governorate',g); if(q)params.set('q',q);
 list.innerHTML='<div class="loading">جاري التحميل...</div>';
 fetch('/api/education/institutions?'+params).then(r=>r.json()).then(x=>{const data=x.data||[];list.innerHTML=data.length?data.map(i=>`<article class="education-card"><h3>${esc(i.name_ar)}</h3><div class="meta">${esc(i.type_label||i.institution_type)}${i.governorate?' · '+esc(i.governorate):''}${i.district?' · '+esc(i.district):''}</div><p>${esc(i.description||'')}</p><div class="tags">${(i.specialties||[]).map(s=>`<span class="tag">${esc(s.name_ar)}${s.degree_level?' — '+esc(s.degree_level):''}</span>`).join('')}</div></article>`).join(''):'<div class="loading">لا توجد مؤسسات مطابقة.</div>';}).catch(()=>list.innerHTML='<div class="loading">تعذر تحميل بيانات التعليم.</div>');
 document.getElementById('educationSearch')?.addEventListener('click',loadEducation); document.getElementById('educationRefresh')?.addEventListener('click',loadEducation);
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
