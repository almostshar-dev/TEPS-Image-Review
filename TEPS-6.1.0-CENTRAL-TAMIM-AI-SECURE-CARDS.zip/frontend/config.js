window.TAMIM_API_BASE = window.TAMIM_API_BASE || (window.location.origin + '');
