افتح celebrities.html عبر خادم الويب نفسه الذي يقدم /api لتعمل طلبات AJAX.
