<?php
return [
 'app_env'=>getenv('APP_ENV') ?: 'production',
 'debug'=>(getenv('APP_DEBUG') ?: '0')==='1',
 'session_days'=>(int)(getenv('TAMIM_SESSION_DAYS') ?: 30),
 'encryption_key'=>getenv('TAMIM_ENCRYPTION_KEY') ?: '',
 'allowed_origins'=>array_values(array_filter(array_map('trim',explode(',',getenv('TAMIM_ALLOWED_ORIGINS') ?: '')))),
];
