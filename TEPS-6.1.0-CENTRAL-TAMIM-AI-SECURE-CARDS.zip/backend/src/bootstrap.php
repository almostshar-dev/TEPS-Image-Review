<?php
declare(strict_types=1);
require_once __DIR__.'/env.php';
$driver=strtolower((string)(function_exists('tamim_env') ? (tamim_env('TAMIM_DB_DRIVER','sqlite') ?: 'sqlite') : (getenv('TAMIM_DB_DRIVER') ?: 'sqlite')));
if($driver==='mysql'){
    $env=function_exists('tamim_env')?'tamim_env':'getenv'; $host=$env('TAMIM_DB_HOST','127.0.0.1') ?: '127.0.0.1'; $port=$env('TAMIM_DB_PORT','3306') ?: '3306'; $name=$env('TAMIM_DB_NAME','tamim') ?: 'tamim'; $user=$env('TAMIM_DB_USER','tamim') ?: 'tamim'; $pass=$env('TAMIM_DB_PASS','') ?? '';
    $db=new PDO("mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
}else{
    $dbDir=dirname(__DIR__).'/storage'; if(!is_dir($dbDir)) mkdir($dbDir,0775,true);
    $db=new PDO('sqlite:'.$dbDir.'/tamim.sqlite'); $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC); $db->exec('PRAGMA foreign_keys=ON');
    require_once __DIR__.'/schema_registry.php'; $platformSchemaState=load_platform_schemas($db);
}
function json_response(array $data,int $status=200):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function request_json():array{$raw=file_get_contents('php://input');$d=json_decode($raw?:'{}',true);return is_array($d)?$d:[];}
function bearer_token():?string{$h=$_SERVER['HTTP_AUTHORIZATION']??'';return preg_match('/Bearer\s+(.+)/i',$h,$m)?trim($m[1]):null;}
function auth_user(PDO $db):?array{$t=bearer_token();if(!$t)return null;$s=$db->prepare('SELECT u.*,p.full_name,p.verified_status,p.gender,p.nationality,p.birth_place,p.birth_date,p.id_type,p.id_number,p.id_issue_date,p.primary_phone,p.alternate_phone FROM users u JOIN profiles p ON p.user_id=u.id WHERE u.api_token=? LIMIT 1');$s->execute([$t]);$u=$s->fetch();if($u){unset($u['api_token'],$u['password_hash']);}return $u?:null;}
function require_user(PDO $db,array $roles=[]):array{$u=function_exists('prod_auth_user')?prod_auth_user($db):auth_user($db);if(!$u)json_response(['error'=>'غير مصرح. سجل الدخول أولاً.'],401);if($roles&&!in_array($u['role'],$roles,true))json_response(['error'=>'ليس لديك صلاحية لهذا الإجراء.'],403);return $u;}
function audit(PDO $db,?int $uid,string $action,?string $type=null,?int $eid=null,?array $details=null):void{$s=$db->prepare('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?)');$s->execute([$uid,$action,$type,$eid,$details?json_encode($details,JSON_UNESCAPED_UNICODE):null]);}
function notify(PDO $db,int $uid,string $title,string $body):void{$s=$db->prepare('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)');$s->execute([$uid,$title,$body]);}
function teps_ensure_default_admin(PDO $db): void {
    // First-install administrator requested by the platform owner. The password is stored only as a one-way hash.
    try {
        $count=(int)$db->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
        if($count>0) return;
        $phone='770360262';
        $q=$db->prepare('SELECT id FROM users WHERE phone=? LIMIT 1'); $q->execute([$phone]);
        if($q->fetchColumn()!==false) return;
        $hash='$2y$12$Xy4j6w/gr7dsvoHUuG6dyOjFw5FHBF/x0QdhpJ9d7.55aT2PZtr6G';
        $token=bin2hex(random_bytes(32));
        $db->beginTransaction();
        $st=$db->prepare('INSERT INTO users(phone,email,password_hash,role,status,phone_serial,api_token) VALUES(?,?,?,?,?,?,?)');
        $st->execute([$phone,null,$hash,'admin','active','TEPS-ADMIN-DEFAULT',$token]);
        $uid=(int)$db->lastInsertId();
        $st=$db->prepare('INSERT INTO profiles(user_id,full_name,language,verified_status,gender,nationality,primary_phone) VALUES(?,?,?,?,?,?,?)');
        $st->execute([$uid,'المدير','ar','approved',null,null,$phone]);
        $db->commit();
    } catch(Throwable $e) {
        if($db->inTransaction()) $db->rollBack();
        // Never block normal platform requests if an older database schema is incomplete.
    }
}
teps_ensure_default_admin($db);
function upload_file(array $file,string $folder,array $allowed,int $maxBytes):string{if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('فشل رفع الملف');if(($file['size']??0)>$maxBytes)throw new RuntimeException('حجم الملف أكبر من الحد المسموح');$finfo=new finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($file['tmp_name']);if(!in_array($mime,$allowed,true))throw new RuntimeException('نوع الملف غير مسموح');$root=dirname(__DIR__).'/storage/uploads/'.$folder;if(!is_dir($root))mkdir($root,0775,true);$ext=match($mime){'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','application/pdf'=>'pdf','audio/mpeg'=>'mp3','audio/wav'=>'wav','audio/x-wav'=>'wav','audio/ogg'=>'ogg','audio/webm'=>'webm',default=>'bin'};$name=bin2hex(random_bytes(16)).'.'.$ext;$dest=$root.'/'.$name;if(!move_uploaded_file($file['tmp_name'],$dest))throw new RuntimeException('تعذر حفظ الملف');return 'uploads/'.$folder.'/'.$name;}
