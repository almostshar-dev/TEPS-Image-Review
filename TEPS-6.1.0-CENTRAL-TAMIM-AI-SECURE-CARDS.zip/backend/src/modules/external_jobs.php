<?php
declare(strict_types=1);

/**
 * Stage 18 — External jobs pipeline.
 * Only accepts jobs supplied by authorized APIs/feeds or manually imported data.
 */
function ext_job_hash(array $j): string {
    $base=mb_strtolower(trim(($j['title']??'').'|'.($j['company_name']??'').'|'.($j['location']??'').'|'.($j['description']??'').'|'.($j['source_url']??'')), 'UTF-8');
    return hash('sha256',$base);
}
function external_jobs_routes(PDO $db,string $method,string $path,array $user): bool {
    if (($user['role']??'')!=='admin' && str_starts_with($path,'/api/v1/external-jobs/')) {
        json_response(['error'=>'Forbidden'],403); return true;
    }
    if ($method==='GET' && $path==='/api/v1/external-jobs/sources') {
        $rows=$db->query("SELECT * FROM external_job_sources ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
        json_response(['sources'=>$rows]); return true;
    }
    if ($method==='POST' && $path==='/api/v1/external-jobs/sources') {
        $b=json_decode(file_get_contents('php://input'),true)?:[];
        $q=$db->prepare("INSERT INTO external_job_sources(name,base_url,source_type,api_endpoint,terms_url,enabled,requires_review) VALUES(?,?,?,?,?,?,?)");
        $q->execute([(string)($b['name']??''),$b['base_url']??null,$b['source_type']??'api',$b['api_endpoint']??null,$b['terms_url']??null,(int)($b['enabled']??0),(int)($b['requires_review']??1)]);
        json_response(['success'=>true,'id'=>(int)$db->lastInsertId()],201); return true;
    }
    if ($method==='POST' && $path==='/api/v1/external-jobs/import') {
        $b=json_decode(file_get_contents('php://input'),true)?:[];
        $source=(int)($b['source_id']??0); $jobs=$b['jobs']??[];
        if(!$source || !is_array($jobs)){json_response(['error'=>'source_id and jobs are required'],422);return true;}
        $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME));
        $sql=$driver==='mysql' ? "INSERT IGNORE INTO external_jobs
            (source_id,external_id,title,company_name,description,location,country_code,category,employment_type,salary_text,source_url,published_at,raw_json,content_hash)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)" : "INSERT OR IGNORE INTO external_jobs
            (source_id,external_id,title,company_name,description,location,country_code,category,employment_type,salary_text,source_url,published_at,raw_json,content_hash)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $ins=$db->prepare($sql);
        $count=0;
        foreach($jobs as $j){
            if(!is_array($j) || trim((string)($j['title']??''))==='') continue;
            $ins->execute([$source,(string)($j['external_id']??''),$j['title'],$j['company_name']??null,$j['description']??null,$j['location']??null,
                $j['country_code']??'YE',$j['category']??null,$j['employment_type']??null,$j['salary_text']??null,$j['source_url']??null,
                $j['published_at']??null,json_encode($j,JSON_UNESCAPED_UNICODE),ext_job_hash($j)]);
            $count += $ins->rowCount();
        }
        json_response(['success'=>true,'imported'=>$count]); return true;
    }
    if ($method==='GET' && $path==='/api/v1/external-jobs/review') {
        $rows=$db->query("SELECT e.*,s.name source_name FROM external_jobs e JOIN external_job_sources s ON s.id=e.source_id WHERE e.normalized_status='pending' ORDER BY e.id DESC")->fetchAll(PDO::FETCH_ASSOC);
        json_response(['jobs'=>$rows]); return true;
    }
    if ($method==='POST' && preg_match('#^/api/v1/external-jobs/(\d+)/review$#',$path,$m)) {
        $id=(int)$m[1]; $b=json_decode(file_get_contents('php://input'),true)?:[];
        $status=$b['status']??'rejected';
        if(!in_array($status,['approved','rejected'],true)){json_response(['error'=>'Invalid status'],422);return true;}
        $q=$db->prepare("UPDATE external_jobs SET normalized_status=?,rejection_reason=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
        $q->execute([$status,$b['rejection_reason']??null,$id]);
        json_response(['success'=>true]); return true;
    }
    if ($method==='GET' && $path==='/api/v1/external-jobs/public') {
        $q=$db->query("SELECT id,title,company_name,description,location,country_code,category,employment_type,salary_text,source_url,published_at FROM external_jobs WHERE normalized_status='approved' ORDER BY COALESCE(published_at,created_at) DESC LIMIT 100");
        json_response(['jobs'=>$q->fetchAll(PDO::FETCH_ASSOC)]); return true;
    }
    return false;
}
