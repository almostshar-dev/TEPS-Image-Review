<?php
declare(strict_types=1);

function payment_methods_migrate(PDO $db): void {
    $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME));
    $cols=[];
    if($driver==='mysql') {
        $rows=$db->query('SHOW COLUMNS FROM payment_methods')->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as $r)$cols[$r['Field']]=true;
        foreach(['account_name'=>'TEXT NULL','account_number'=>'TEXT NULL','payment_point'=>'TEXT NULL','notes'=>'TEXT NULL','updated_at'=>'DATETIME NULL'] as $c=>$type) {
            if(!isset($cols[$c])) $db->exec("ALTER TABLE payment_methods ADD COLUMN {$c} {$type}");
        }
    } else {
        $rows=$db->query('PRAGMA table_info(payment_methods)')->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as $r)$cols[$r['name']]=true;
        foreach(['account_name'=>'TEXT','account_number'=>'TEXT','payment_point'=>'TEXT','notes'=>'TEXT','updated_at'=>'TEXT'] as $c=>$type) {
            if(!isset($cols[$c])) $db->exec("ALTER TABLE payment_methods ADD COLUMN {$c} {$type}");
        }
    }
}
function payment_methods_list(PDO $db): array {
    payment_methods_migrate($db);
    return $db->query('SELECT id,name_ar,name_en,method_type,account_reference,account_name,account_number,payment_point,notes,is_enabled,sort_order,created_at,updated_at FROM payment_methods ORDER BY method_type,sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
}
function payment_method_save(PDO $db,array $d): array {
    payment_methods_migrate($db);
    $id=(int)($d['id']??0);
    $name=trim((string)($d['name_ar']??''));
    $type=trim((string)($d['method_type']??'wallet'));
    if($name==='') throw new InvalidArgumentException('اسم المحفظة أو البنك مطلوب.');
    if(!in_array($type,['wallet','bank','other'],true)) throw new InvalidArgumentException('نوع وسيلة الدفع غير صالح.');
    $accountName=trim((string)($d['account_name']??''));
    $accountNumber=trim((string)($d['account_number']??''));
    $point=trim((string)($d['payment_point']??''));
    $notes=trim((string)($d['notes']??''));
    $en=trim((string)($d['name_en']??''));
    $ref=trim((string)($d['account_reference']??''));
    $enabled=array_key_exists('is_enabled',$d)?(int)!empty($d['is_enabled']):1;
    $sort=(int)($d['sort_order']??0);
    if($id){
        $s=$db->prepare('UPDATE payment_methods SET name_ar=?,name_en=?,method_type=?,account_reference=?,account_name=?,account_number=?,payment_point=?,notes=?,is_enabled=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');
        $s->execute([$name,$en?:null,$type,$ref?:null,$accountName?:null,$accountNumber?:null,$point?:null,$notes?:null,$enabled,$sort,$id]);
    } else {
        $s=$db->prepare('INSERT INTO payment_methods(name_ar,name_en,method_type,account_reference,account_name,account_number,payment_point,notes,is_enabled,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $s->execute([$name,$en?:null,$type,$ref?:null,$accountName?:null,$accountNumber?:null,$point?:null,$notes?:null,$enabled,$sort]);
        $id=(int)$db->lastInsertId();
    }
    $s=$db->prepare('SELECT id,name_ar,name_en,method_type,account_reference,account_name,account_number,payment_point,notes,is_enabled,sort_order,created_at,updated_at FROM payment_methods WHERE id=?');$s->execute([$id]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: [];
}
function payment_method_toggle(PDO $db,int $id,bool $enabled): array {
    payment_methods_migrate($db);
    $s=$db->prepare('UPDATE payment_methods SET is_enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$s->execute([(int)$enabled,$id]);
    if($s->rowCount()===0) throw new RuntimeException('وسيلة الدفع غير موجودة.');
    $s=$db->prepare('SELECT id,name_ar,name_en,method_type,account_reference,account_name,account_number,payment_point,notes,is_enabled,sort_order,created_at,updated_at FROM payment_methods WHERE id=?');$s->execute([$id]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: [];
}
