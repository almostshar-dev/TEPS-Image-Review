<?php
declare(strict_types=1);

function teps_catalog_ensure(PDO $db): void {
    $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME));
    if($driver==='mysql'){
        $sqls=[
            "CREATE TABLE IF NOT EXISTS teps_companies (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(255) NOT NULL,description TEXT NULL,phone VARCHAR(80) NULL,email VARCHAR(190) NULL,address VARCHAR(500) NULL,website VARCHAR(500) NULL,governorate VARCHAR(120) NULL,district VARCHAR(120) NULL,verification_status VARCHAR(40) NOT NULL DEFAULT 'approved',status VARCHAR(40) NOT NULL DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS teps_institutions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name_ar VARCHAR(255) NOT NULL,name_en VARCHAR(255) NULL,institution_type VARCHAR(100) NULL,description TEXT NULL,phone VARCHAR(80) NULL,email VARCHAR(190) NULL,address VARCHAR(500) NULL,governorate VARCHAR(120) NULL,district VARCHAR(120) NULL,status VARCHAR(40) NOT NULL DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS teps_facilities (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name_ar VARCHAR(255) NOT NULL,facility_type VARCHAR(100) NULL,description TEXT NULL,phone VARCHAR(80) NULL,address VARCHAR(500) NULL,governorate VARCHAR(120) NULL,district VARCHAR(120) NULL,status VARCHAR(40) NOT NULL DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS teps_services (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(255) NOT NULL,category VARCHAR(120) NULL,description TEXT NULL,fee DECIMAL(12,2) NOT NULL DEFAULT 0,status VARCHAR(40) NOT NULL DEFAULT 'approved',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS teps_departments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,department_key VARCHAR(100) NOT NULL UNIQUE,name_ar VARCHAR(255) NOT NULL,description TEXT NULL,icon VARCHAR(30) NULL,path VARCHAR(500) NULL,status VARCHAR(40) NOT NULL DEFAULT 'active',sort_order INT NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        ];
    }else{
        $sqls=[
            "CREATE TABLE IF NOT EXISTS teps_companies (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT,phone TEXT,email TEXT,address TEXT,website TEXT,governorate TEXT,district TEXT,verification_status TEXT DEFAULT 'approved',status TEXT DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS teps_institutions (id INTEGER PRIMARY KEY AUTOINCREMENT,name_ar TEXT NOT NULL,name_en TEXT,institution_type TEXT,description TEXT,phone TEXT,email TEXT,address TEXT,governorate TEXT,district TEXT,status TEXT DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS teps_facilities (id INTEGER PRIMARY KEY AUTOINCREMENT,name_ar TEXT NOT NULL,facility_type TEXT,description TEXT,phone TEXT,address TEXT,governorate TEXT,district TEXT,status TEXT DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS teps_services (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,description TEXT,fee REAL DEFAULT 0,status TEXT DEFAULT 'approved',created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS teps_departments (id INTEGER PRIMARY KEY AUTOINCREMENT,department_key TEXT UNIQUE NOT NULL,name_ar TEXT NOT NULL,description TEXT,icon TEXT,path TEXT,status TEXT DEFAULT 'active',sort_order INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP)"
        ];
    }
    foreach($sqls as $sql)$db->exec($sql);
    $defaults=[
        ['jobs','الوظائف','البحث عن الوظائف والتقديم عليها','💼','/frontend/jobs/index.html',10],
        ['companies','الشركات والمؤسسات','الشركات والمؤسسات والجهات المعتمدة','🏢','/frontend/companies/index.html',20],
        ['services','الخدمات العامة','الخدمات العامة والطلبات الإلكترونية','🏛️','/public-services/index.html',30],
        ['medical','الطب والصحة','المستشفيات والمراكز والعيادات والأطباء','🏥','/frontend/medical/index.html',40],
        ['education','التعليم','الجامعات والكليات والمعاهد والخدمات التعليمية','🎓','/frontend/education/index.html',50],
        ['tourism','السياحة والفنادق','الفنادق والسياحة والحجوزات','✈️','/frontend/tourism.html',60],
        ['events','الأعراس والفعاليات','الفعاليات والحجوزات والخدمات','🎉','/frontend/events.html',70],
        ['celebrities','المشاهير والمؤثرون','المشاهير والمؤثرون والحجوزات','⭐','/frontend/celebrities.html',80],
        ['payments','المدفوعات','الفواتير والدفع وإيصالات التحويل','💳','/frontend/finance.html',90],
        ['rewards','المكافآت والهدايا','النقاط والمكافآت والإحالات','🎁','/frontend/rewards.html',100],
        ['support','الدعم والدردشة','الدردشة المباشرة مع الإدارة والمختصين','💬','/frontend/messages/index.html',110]
    ];
    $ins=$db->prepare('INSERT IGNORE INTO teps_departments(department_key,name_ar,description,icon,path,sort_order) VALUES(?,?,?,?,?,?)');
    foreach($defaults as $d)$ins->execute($d);
}
function teps_catalog_table(PDO $db,string $entity): array {
    $map=[
        'companies'=>['table'=>'teps_companies','fields'=>['name','description','phone','email','address','website','governorate','district','verification_status','status'],'label'=>'الشركات'],
        'institutions'=>['table'=>'teps_institutions','fields'=>['name_ar','name_en','institution_type','description','phone','email','address','governorate','district','status'],'label'=>'المؤسسات'],
        'facilities'=>['table'=>'teps_facilities','fields'=>['name_ar','facility_type','description','phone','address','governorate','district','status'],'label'=>'المنشآت'],
        'services'=>['table'=>'teps_services','fields'=>['name','category','description','fee','status'],'label'=>'الخدمات'],
        'departments'=>['table'=>'teps_departments','fields'=>['department_key','name_ar','description','icon','path','status','sort_order'],'label'=>'الأقسام']
    ];
    if(!isset($map[$entity]))json_response(['error'=>'القسم غير معروف'],404);
    return $map[$entity];
}
function teps_catalog_route(PDO $db,string $path,string $method): bool {
    if(!str_starts_with($path,'/api/admin/catalog')) return false;
    $u=require_user($db,['admin']); teps_catalog_ensure($db);
    if($path==='/api/admin/catalog/users'&&$method==='GET'){
        $sql="SELECT u.id,u.phone,u.email,u.role,u.status,u.created_at,u.last_login,p.full_name,p.verified_status FROM users u LEFT JOIN profiles p ON p.user_id=u.id ORDER BY u.id DESC LIMIT 1000";
        json_response(['data'=>$db->query($sql)->fetchAll()]);
    }
    if(preg_match('#^/api/admin/catalog/governorates(?:/(\d+))?$#',$path,$m)){
        $id=isset($m[1])?(int)$m[1]:0;
        if($method==='GET'&&!$id){try{$rows=$db->query('SELECT id,code,name_ar,name_en,capital_ar,is_active FROM yemen_governorates ORDER BY name_ar')->fetchAll();}catch(Throwable $e){$rows=[];}json_response(['data'=>$rows]);}
        $d=request_json();
        if($method==='POST'&&!$id){$name=trim((string)($d['name_ar']??''));if($name==='')json_response(['error'=>'اسم المحافظة مطلوب'],422);try{$st=$db->prepare('INSERT INTO yemen_governorates(code,name_ar,name_en,capital_ar,is_active) VALUES(?,?,?,?,1)');$st->execute([trim((string)($d['code']??''))?:'GOV-'.strtoupper(bin2hex(random_bytes(2))),$name,$d['name_en']??null,$d['capital_ar']??null]);json_response(['message'=>'تمت إضافة المحافظة','id'=>(int)$db->lastInsertId()],201);}catch(Throwable $e){json_response(['error'=>'تعذر إضافة المحافظة.'],422);}}
        if($id&&$method==='PUT'){try{$st=$db->prepare('UPDATE yemen_governorates SET code=?,name_ar=?,name_en=?,capital_ar=?,is_active=? WHERE id=?');$st->execute([$d['code']??'',trim((string)($d['name_ar']??'')),$d['name_en']??null,$d['capital_ar']??null,!empty($d['is_active'])?1:0,$id]);json_response(['message'=>'تم تحديث المحافظة']);}catch(Throwable $e){json_response(['error'=>'تعذر تحديث المحافظة.'],422);}}
        if($id&&$method==='DELETE'){try{$db->prepare('DELETE FROM yemen_governorates WHERE id=?')->execute([$id]);json_response(['message'=>'تم حذف المحافظة']);}catch(Throwable $e){json_response(['error'=>'لا يمكن حذف المحافظة المرتبطة بمديريات.'],422);}}
    }
    if(preg_match('#^/api/admin/catalog/districts(?:/(\d+))?$#',$path,$m)){
        $id=isset($m[1])?(int)$m[1]:0;
        if($method==='GET'&&!$id){$gov=(int)($_GET['governorate_id']??0);try{$st=$gov?$db->prepare('SELECT id,code,governorate_id,name_ar,name_en,latitude,longitude,is_active FROM yemen_districts WHERE governorate_id=? ORDER BY name_ar'):$db->query('SELECT id,code,governorate_id,name_ar,name_en,latitude,longitude,is_active FROM yemen_districts ORDER BY name_ar');if($gov)$st->execute([$gov]);$rows=$st->fetchAll();}catch(Throwable $e){$rows=[];}json_response(['data'=>$rows]);}
        $d=request_json();
        if($method==='POST'&&!$id){$name=trim((string)($d['name_ar']??''));$gov=(int)($d['governorate_id']??0);if($name===''||$gov<1)json_response(['error'=>'اسم المديرية والمحافظة مطلوبان'],422);try{$st=$db->prepare('INSERT INTO yemen_districts(code,governorate_id,name_ar,name_en,is_active) VALUES(?,?,?,?,1)');$st->execute([trim((string)($d['code']??''))?:'DIST-'.strtoupper(bin2hex(random_bytes(2))),$gov,$name,$d['name_en']??null]);json_response(['message'=>'تمت إضافة المديرية','id'=>(int)$db->lastInsertId()],201);}catch(Throwable $e){json_response(['error'=>'تعذر إضافة المديرية.'],422);}}
        if($id&&$method==='PUT'){try{$st=$db->prepare('UPDATE yemen_districts SET code=?,governorate_id=?,name_ar=?,name_en=?,is_active=? WHERE id=?');$st->execute([$d['code']??'',(int)($d['governorate_id']??0),trim((string)($d['name_ar']??'')),$d['name_en']??null,!empty($d['is_active'])?1:0,$id]);json_response(['message'=>'تم تحديث المديرية']);}catch(Throwable $e){json_response(['error'=>'تعذر تحديث المديرية.'],422);}}
        if($id&&$method==='DELETE'){try{$db->prepare('DELETE FROM yemen_districts WHERE id=?')->execute([$id]);json_response(['message'=>'تم حذف المديرية']);}catch(Throwable $e){json_response(['error'=>'تعذر حذف المديرية.'],422);}}
    }
    if(preg_match('#^/api/admin/catalog/(companies|institutions|facilities|services|departments)(?:/(\d+))?$#',$path,$m)){
        $entity=$m[1];$id=isset($m[2])?(int)$m[2]:0;$c=teps_catalog_table($db,$entity);$table=$c['table'];
        if($method==='GET' && !$id){$rows=$db->query('SELECT * FROM `'.$table.'` ORDER BY id DESC')->fetchAll();json_response(['data'=>$rows,'label'=>$c['label']]);}
        $d=request_json();
        if($method==='POST' && !$id){
            $cols=[];$vals=[];foreach($c['fields'] as $f){if(array_key_exists($f,$d)){$cols[]=$f;$vals[]=$d[$f];}}
            if(in_array('name',$c['fields'],true)&&trim((string)($d['name']??''))==='')json_response(['error'=>'الاسم مطلوب'],422);
            if(in_array('name_ar',$c['fields'],true)&&trim((string)($d['name_ar']??''))==='')json_response(['error'=>'الاسم مطلوب'],422);
            if(!$cols)json_response(['error'=>'لا توجد بيانات للحفظ'],422);
            $sql='INSERT INTO `'.$table.'` (`'.implode('`,`',$cols).'`) VALUES ('.implode(',',array_fill(0,count($cols),'?')).')';$st=$db->prepare($sql);$st->execute($vals);$new=(int)$db->lastInsertId();audit($db,(int)$u['id'],'catalog_created',$entity,$new);json_response(['message'=>'تمت الإضافة بنجاح','id'=>$new],201);
        }
        if($id && $method==='PUT'){
            $cols=[];$vals=[];foreach($c['fields'] as $f)if(array_key_exists($f,$d)){$cols[]=$f;$vals[]=$d[$f];}
            if(!$cols)json_response(['error'=>'لا توجد بيانات للتحديث'],422);
            $st=$db->prepare('UPDATE `'.$table.'` SET '.implode(',',array_map(fn($x)=>'`'.$x.'`=?',$cols)).' WHERE id=?');$st->execute([...$vals,$id]);audit($db,(int)$u['id'],'catalog_updated',$entity,$id);json_response(['message'=>'تم التحديث بنجاح']);
        }
        if($id && $method==='DELETE'){$st=$db->prepare('DELETE FROM `'.$table.'` WHERE id=?');$st->execute([$id]);audit($db,(int)$u['id'],'catalog_deleted',$entity,$id);json_response(['message'=>'تم الحذف بنجاح']);}
    }
    return true;
}
