<?php
declare(strict_types=1);

function homepage_public(PDO $db): void {
    $sections = $db->query("SELECT section_key, enabled, sort_order FROM homepage_sections WHERE enabled=1 ORDER BY sort_order,id")->fetchAll();
    $cards = $db->query("SELECT slot_no, image_path, link_url FROM homepage_cards WHERE is_active=1 AND image_path IS NOT NULL AND image_path<>'' AND (starts_at IS NULL OR starts_at='' OR starts_at<=UTC_TIMESTAMP()) AND (ends_at IS NULL OR ends_at='' OR ends_at>=UTC_TIMESTAMP()) ORDER BY sort_order,slot_no LIMIT 4")->fetchAll();
    $companies = $db->query("SELECT ep.id, ep.business_name, ep.business_type, ep.governorate, ep.district, ep.description, ep.logo_path, ep.created_at FROM employer_profiles ep JOIN users u ON u.id=ep.user_id WHERE u.status='active' AND ep.verification_status='approved' ORDER BY ep.id ASC")->fetchAll();
    try { $extra=$db->query("SELECT id,name AS business_name,NULL AS business_type,governorate,district,description,NULL AS logo_path,created_at FROM teps_companies WHERE status='active' AND verification_status='approved' ORDER BY id ASC")->fetchAll(); $companies=array_merge($companies,$extra); } catch(Throwable $e) {}
    json_response(['sections'=>$sections,'greetings'=>$cards,'companies'=>$companies]);
}
function homepage_admin(PDO $db): void {
    require_user($db,['admin']);
    $sections=$db->query("SELECT * FROM homepage_sections ORDER BY sort_order,id")->fetchAll();
    $cards=$db->query("SELECT * FROM homepage_cards ORDER BY slot_no")->fetchAll();
    json_response(['sections'=>$sections,'cards'=>$cards]);
}
function homepage_admin_update_section(PDO $db,string $key,array $d): void {
    require_user($db,['admin']);
    $allowed=['home','greetings','quick','companies','jobs','services','education','stats','about','footer'];
    if(!in_array($key,$allowed,true)) json_response(['error'=>'القسم غير صالح'],422);
    $enabled=!empty($d['enabled'])?1:0;
    $s=$db->prepare('UPDATE homepage_sections SET enabled=? WHERE section_key=?'); $s->execute([$enabled,$key]);
    audit($db,null,'homepage_section_changed','homepage_section',null,['section_key'=>$key,'enabled'=>$enabled]);
    json_response(['message'=>'تم تحديث ظهور القسم']);
}
function homepage_admin_save_card(PDO $db,int $slot,array $d): void {
    $u=require_user($db,['admin']);
    if($slot<1||$slot>4) json_response(['error'=>'رقم البطاقة يجب أن يكون من 1 إلى 4'],422);
    $title=trim((string)($d['internal_title']??'')); $link=trim((string)($d['link_url']??'')); $button=trim((string)($d['button_text']??''));
    $sort=max(0,(int)($d['sort_order']??$slot)); $active=!empty($d['is_active'])?1:0;
    $start=trim((string)($d['starts_at']??''))?:null; $end=trim((string)($d['ends_at']??''))?:null;
    $sql='UPDATE homepage_cards SET internal_title=?,link_url=?,button_text=?,sort_order=?,is_active=?,starts_at=?,ends_at=?,updated_at=UTC_TIMESTAMP() WHERE slot_no=?';
    $st=$db->prepare($sql);$st->execute([$title,$link?:null,$button?:null,$sort,$active,$start,$end,$slot]);
    audit($db,(int)$u['id'],'homepage_card_saved','homepage_card',$slot,['title'=>$title]);
    json_response(['message'=>'تم حفظ البطاقة']);
}
function homepage_admin_upload_card(PDO $db,int $slot,array $file): void {
    $u=require_user($db,['admin']);
    if($slot<1||$slot>4) json_response(['error'=>'رقم البطاقة غير صالح'],422);
    if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) json_response(['error'=>'اختر صورة صالحة'],422);
    if(($file['size']??0)>5242880) json_response(['error'=>'حجم الصورة يتجاوز 5MB'],422);
    $f=new finfo(FILEINFO_MIME_TYPE); $mime=$f->file($file['tmp_name']);
    $map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if(!isset($map[$mime])) json_response(['error'=>'يسمح فقط JPG وPNG وWEBP'],422);
    $dir=dirname(__DIR__,3).'/uploads/homepage'; if(!is_dir($dir)) @mkdir($dir,0775,true);
    $name='card_'.$slot.'_'.bin2hex(random_bytes(12)).'.'.$map[$mime]; $dest=$dir.'/'.$name;
    if(!move_uploaded_file($file['tmp_name'],$dest)) json_response(['error'=>'تعذر حفظ الصورة'],500);
    $path='/uploads/homepage/'.$name;
    $st=$db->prepare('UPDATE homepage_cards SET image_path=?,updated_at=UTC_TIMESTAMP() WHERE slot_no=?');$st->execute([$path,$slot]);
    audit($db,(int)$u['id'],'homepage_card_image_uploaded','homepage_card',$slot,['path'=>$path]);
    json_response(['message'=>'تم رفع الصورة','image_path'=>$path]);
}
