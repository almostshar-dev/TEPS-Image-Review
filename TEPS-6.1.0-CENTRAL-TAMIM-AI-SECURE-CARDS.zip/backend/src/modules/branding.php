<?php
declare(strict_types=1);

function branding_ensure(PDO $db): void {
    static $done=false; if($done)return;
    $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME));
    if($driver==='mysql'){
        $db->exec("CREATE TABLE IF NOT EXISTS platform_branding (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            platform_name VARCHAR(190) NOT NULL DEFAULT 'منصة التميم للتوظيف والخدمات العامة',
            platform_short_name VARCHAR(100) NOT NULL DEFAULT 'منصة التميم',
            company_name VARCHAR(190) NULL,
            slogan VARCHAR(255) NULL,
            phone VARCHAR(100) NULL,
            email VARCHAR(190) NULL,
            website VARCHAR(255) NULL,
            address VARCHAR(500) NULL,
            registration_no VARCHAR(150) NULL,
            report_header TEXT NULL,
            report_footer TEXT NULL,
            logo_path VARCHAR(500) NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } else {
        $db->exec("CREATE TABLE IF NOT EXISTS platform_branding (
            id INTEGER PRIMARY KEY AUTOINCREMENT, platform_name TEXT NOT NULL DEFAULT 'منصة التميم للتوظيف والخدمات العامة',
            platform_short_name TEXT NOT NULL DEFAULT 'منصة التميم', company_name TEXT, slogan TEXT, phone TEXT, email TEXT,
            website TEXT, address TEXT, registration_no TEXT, report_header TEXT, report_footer TEXT, logo_path TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )");
    }
    $n=(int)$db->query('SELECT COUNT(*) FROM platform_branding')->fetchColumn();
    if($n===0){$db->exec("INSERT INTO platform_branding(platform_name,platform_short_name) VALUES('منصة التميم للتوظيف والخدمات العامة','منصة التميم')");}
    $done=true;
}
function branding_get(PDO $db): array { branding_ensure($db); return $db->query('SELECT * FROM platform_branding ORDER BY id LIMIT 1')->fetch() ?: []; }
function branding_public(PDO $db): void { $b=branding_get($db); json_response(['data'=>$b]); }
function branding_admin(PDO $db,string $method,string $path): bool {
    if($path==='/api/branding'&&$method==='GET'){branding_public($db);return true;}
    if(!str_starts_with($path,'/api/admin/branding')) return false;
    $u=prod_require_user($db,['admin']); branding_ensure($db);
    if($path==='/api/admin/branding'&&$method==='GET'){json_response(['data'=>branding_get($db)]);return true;}
    if($path==='/api/admin/branding'&&$method==='PUT'){
        $d=request_json(); $fields=['platform_name','platform_short_name','company_name','slogan','phone','email','website','address','registration_no','report_header','report_footer'];
        $set=[];$vals=[];foreach($fields as $f){if(array_key_exists($f,$d)){$set[]="$f=?";$vals[]=$d[$f]===null?null:trim((string)$d[$f]);}}
        if(!$set)json_response(['error'=>'لا توجد بيانات للتحديث'],422);$vals[]=1;$db->prepare('UPDATE platform_branding SET '.implode(',',$set).',updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute($vals);audit($db,(int)$u['id'],'branding_updated','platform_branding',1);json_response(['message'=>'تم حفظ بيانات الترويسة والمنصة','data'=>branding_get($db)]);return true;
    }
    if($path==='/api/admin/branding/logo'&&$method==='POST'){
        $f=$_FILES['logo']??[]; $pathRel=upload_file($f,'branding',['image/jpeg','image/png','image/webp'],5*1024*1024);
        $db->prepare('UPDATE platform_branding SET logo_path=?,updated_at=CURRENT_TIMESTAMP WHERE id=1')->execute([$pathRel]);audit($db,(int)$u['id'],'branding_logo_updated','platform_branding',1);json_response(['message'=>'تم تحديث شعار المنصة','data'=>branding_get($db)]);return true;
    }
    return false;
}
