<?php
declare(strict_types=1);

function unified_services_routes(PDO $db,string $method,string $path,array $user=[]): bool {
    if($path==='/api/reference/governorates' && $method==='GET'){
        $st=$db->query('SELECT id,code,name_ar,name_en,capital_ar FROM yemen_governorates WHERE is_active=1 ORDER BY name_ar');
        json_response(['data'=>$st->fetchAll()]); return true;
    }
    if($path==='/api/reference/districts' && $method==='GET'){
        $gov=(int)($_GET['governorate_id']??0); $st=$gov?$db->prepare('SELECT id,code,governorate_id,name_ar,name_en,latitude,longitude FROM yemen_districts WHERE is_active=1 AND governorate_id=? ORDER BY name_ar'):$db->query('SELECT id,code,governorate_id,name_ar,name_en,latitude,longitude FROM yemen_districts WHERE is_active=1 ORDER BY name_ar');
        if($gov)$st->execute([$gov]); json_response(['data'=>$st->fetchAll()]); return true;
    }
    if($path==='/api/reference/entities' && $method==='GET'){
        $type=trim((string)($_GET['type']??'')); $gov=(int)($_GET['governorate_id']??0); $dist=(int)($_GET['district_id']??0); $q=trim((string)($_GET['q']??''));
        $sql='SELECT e.*,g.name_ar governorate_name,d.name_ar district_name FROM yemen_entities e LEFT JOIN yemen_governorates g ON g.id=e.governorate_id LEFT JOIN yemen_districts d ON d.id=e.district_id WHERE e.status<>"hidden"';$a=[];
        if($type!==''){$sql.=' AND e.entity_type=?';$a[]=$type;} if($gov){$sql.=' AND e.governorate_id=?';$a[]=$gov;} if($dist){$sql.=' AND e.district_id=?';$a[]=$dist;} if($q!==''){$sql.=' AND (e.name_ar LIKE ? OR e.name_en LIKE ? OR e.description LIKE ?)';$x="%$q%";$a=[$a,$x,$x,$x];$a=array_merge(...$a);} $sql.=' ORDER BY e.name_ar LIMIT 200';
        $st=$db->prepare($sql);$st->execute($a);json_response(['data'=>$st->fetchAll()]); return true;
    }
    if($path==='/api/favorites' && $method==='GET'){
        if(!$user) json_response(['error'=>'تسجيل الدخول مطلوب'],401); $st=$db->prepare('SELECT * FROM favorites WHERE user_id=? ORDER BY created_at DESC');$st->execute([$user['id']]);json_response(['data'=>$st->fetchAll()]);return true;
    }
    if($path==='/api/favorites' && $method==='POST'){
        if(!$user) json_response(['error'=>'تسجيل الدخول مطلوب'],401);$d=request_json();$type=trim((string)($d['item_type']??''));$id=(int)($d['item_id']??0);if($type===''||$id<1)json_response(['error'=>'نوع وعنصر المفضلة مطلوبان'],422);
        $st=$db->prepare('INSERT IGNORE INTO favorites(user_id,item_type,item_id,title_snapshot) VALUES(?,?,?,?)');$st->execute([$user['id'],$type,$id,$d['title']??null]);json_response(['message'=>'تمت الإضافة إلى المفضلة']);return true;
    }
    if(preg_match('#^/api/favorites/(\d+)$#',$path,$m)&&$method==='DELETE'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$db->prepare('DELETE FROM favorites WHERE id=? AND user_id=?')->execute([(int)$m[1],$user['id']]);json_response(['message'=>'تمت الإزالة من المفضلة']);return true;
    }
    if($path==='/api/bookings' && $method==='POST'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$d=request_json();foreach(['booking_type','customer_name','customer_phone','booking_date'] as $f)if(trim((string)($d[$f]??''))==='')json_response(['error'=>'بيانات الحجز الأساسية مطلوبة'],422);
        $code='TEPS-BK-'.strtoupper(bin2hex(random_bytes(5)));$st=$db->prepare('INSERT INTO service_bookings(user_id,entity_id,booking_type,customer_name,customer_phone,booking_date,booking_time,quantity,service_name,notes,status,confirmation_code) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');$st->execute([$user['id'],!empty($d['entity_id'])?(int)$d['entity_id']:null,$d['booking_type'],$d['customer_name'],$d['customer_phone'],$d['booking_date'],$d['booking_time']??null,max(1,(int)($d['quantity']??1)),$d['service_name']??null,$d['notes']??null,'new',$code]);json_response(['message'=>'تم إرسال الحجز','booking_id'=>(int)$db->lastInsertId(),'confirmation_code'=>$code],201);return true;
    }
    if($path==='/api/bookings' && $method==='GET'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$st=$db->prepare('SELECT * FROM service_bookings WHERE user_id=? ORDER BY booking_date DESC,booking_time DESC');$st->execute([$user['id']]);json_response(['data'=>$st->fetchAll()]);return true;
    }
    if($path==='/api/job-seeker/cv' && $method==='GET'){if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$st=$db->prepare('SELECT * FROM job_seeker_profiles WHERE user_id=?');$st->execute([$user['id']]);json_response(['data'=>$st->fetch()?:null]);return true;}
    if($path==='/api/job-seeker/cv' && $method==='PUT'){if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$d=request_json();$st=$db->prepare('INSERT INTO job_seeker_profiles(user_id,specialty,qualification,experience_years,skills,desired_job_title,desired_locations,desired_work_type,desired_salary_min,cv_status) VALUES(?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE specialty=VALUES(specialty),qualification=VALUES(qualification),experience_years=VALUES(experience_years),skills=VALUES(skills),desired_job_title=VALUES(desired_job_title),desired_locations=VALUES(desired_locations),desired_work_type=VALUES(desired_work_type),desired_salary_min=VALUES(desired_salary_min),cv_status=VALUES(cv_status)');$st->execute([$user['id'],$d['specialty']??null,$d['qualification']??null,(float)($d['experience_years']??0),$d['skills']??null,$d['desired_job_title']??null,$d['desired_locations']??null,$d['desired_work_type']??null,$d['desired_salary_min']??null,'ready']);$db->prepare("UPDATE user_account_profiles SET account_type='job_seeker' WHERE user_id=?")->execute([$user['id']]);json_response(['message'=>'تم حفظ السيرة الذاتية وتهيئة حساب الباحث عن عمل']);return true;}
    if($path==='/api/profile/preferences' && $method==='GET'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$st=$db->prepare('SELECT * FROM user_account_profiles WHERE user_id=?');$st->execute([$user['id']]);json_response(['data'=>$st->fetch()?:null]);return true;
    }
    if($path==='/api/profile/preferences' && $method==='PUT'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$d=request_json();$st=$db->prepare('INSERT INTO user_account_profiles(user_id,account_type,country_id,governorate_id,district_id,personalization_enabled,location_consent) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE account_type=VALUES(account_type),country_id=VALUES(country_id),governorate_id=VALUES(governorate_id),district_id=VALUES(district_id),personalization_enabled=VALUES(personalization_enabled),location_consent=VALUES(location_consent)');$st->execute([$user['id'],$d['account_type']??'general_user',$d['country_id']??null,$d['governorate_id']??null,$d['district_id']??null,!empty($d['personalization_enabled'])?1:0,!empty($d['location_consent'])?1:0]);json_response(['message'=>'تم حفظ تفضيلات الحساب']);return true;
    }
    if($path==='/api/platform-terms' && $method==='GET'){$st=$db->query('SELECT id,version,terms_text,privacy_text,effective_at FROM platform_terms WHERE is_active=1 ORDER BY id DESC');json_response(['data'=>$st->fetchAll()]);return true;}
    if($path==='/api/social-links' && $method==='GET'){$st=$db->query('SELECT platform,label_ar,url,phone,is_header_visible,is_sidebar_visible,sort_order FROM social_links ORDER BY sort_order');json_response(['data'=>$st->fetchAll()]);return true;}
    if($path==='/api/notifications/preferences' && $method==='GET'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$st=$db->prepare('SELECT * FROM notification_preferences WHERE user_id=?');$st->execute([$user['id']]);json_response(['data'=>$st->fetch()?:null]);return true;
    }
    if($path==='/api/notifications/preferences' && $method==='PUT'){
        if(!$user)json_response(['error'=>'تسجيل الدخول مطلوب'],401);$d=request_json();$cols=['jobs','places','education','medical','bookings','offers','events'];$vals=[];foreach($cols as $c)$vals[$c]=!empty($d[$c])?1:0;$st=$db->prepare('INSERT INTO notification_preferences(user_id,jobs,places,education,medical,bookings,offers,events) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE jobs=VALUES(jobs),places=VALUES(places),education=VALUES(education),medical=VALUES(medical),bookings=VALUES(bookings),offers=VALUES(offers),events=VALUES(events)');$st->execute([$user['id'],...array_values($vals)]);json_response(['message'=>'تم حفظ إعدادات الإشعارات']);return true;
    }
    if($path==='/api/admin/social-links' && $method==='GET'){require_user($db,['admin']);$st=$db->query('SELECT * FROM social_links ORDER BY sort_order');json_response(['data'=>$st->fetchAll()]);return true;}
    if($path==='/api/admin/social-links' && $method==='PUT'){ $u=require_user($db,['admin']);$d=request_json();$platform=trim((string)($d['platform']??''));if($platform==='')json_response(['error'=>'المنصة مطلوبة'],422);$st=$db->prepare('INSERT INTO social_links(platform,label_ar,url,phone,is_header_visible,is_sidebar_visible,sort_order) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE label_ar=VALUES(label_ar),url=VALUES(url),phone=VALUES(phone),is_header_visible=VALUES(is_header_visible),is_sidebar_visible=VALUES(is_sidebar_visible),sort_order=VALUES(sort_order)');$st->execute([$platform,$d['label_ar']??$platform,$d['url']??null,$d['phone']??null,!empty($d['is_header_visible'])?1:0,!empty($d['is_sidebar_visible'])?1:0,(int)($d['sort_order']??0)]);audit($db,(int)$u['id'],'social_link_saved','social_link',null,['platform'=>$platform]);json_response(['message'=>'تم حفظ بيانات التواصل']);return true;}
    return false;
}
