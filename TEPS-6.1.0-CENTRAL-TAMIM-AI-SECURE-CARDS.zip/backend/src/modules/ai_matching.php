<?php
declare(strict_types=1);

/**
 * Stage 17 — AI-ready matching.
 * Uses transparent rule-based scoring as a safe fallback. An external AI provider
 * can later replace extract_profile() without changing API contracts.
 */
function ai_tokens(string $text): array {
    $text = mb_strtolower($text, 'UTF-8');
    $parts = preg_split('/[^\p{L}\p{N}\+#\.-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_unique(array_filter($parts, fn($x)=>mb_strlen($x,'UTF-8')>=2)));
}
function ai_extract_profile(array $profile): array {
    $text = implode(' ', array_map(fn($v)=>is_scalar($v)?(string)$v:'', $profile));
    $tokens = ai_tokens($text);
    $known = ['php','laravel','javascript','typescript','react','flutter','python','java','sql','postgresql',
              'mysql','sqlite','docker','linux','excel','word','marketing','accounting','nursing','medicine',
              'engineering','teaching','sales','design','management','english','arabic'];
    $skills = array_values(array_intersect($tokens,$known));
    $qualification = '';
    foreach (['دكتوراه','بروفيسور','ماجستير','بورد','بكالوريوس','دبلوم','ثانوي','أساسي'] as $q)
        if (mb_strpos($text,$q)!==false) { $qualification=$q; break; }
    return ['skills'=>$skills,'qualification'=>$qualification,'tokens'=>$tokens];
}
function ai_job_score(array $profile, array $job): array {
    $p=ai_extract_profile($profile);
    $jobText=implode(' ',array_map(fn($v)=>is_scalar($v)?(string)$v:'',$job));
    $jt=ai_tokens($jobText);
    $skillHits=array_values(array_intersect($p['skills'],$jt));
    $score=min(100, count($skillHits)*18 + ($p['qualification'] && mb_strpos($jobText,$p['qualification'])!==false ? 20 : 0));
    if ($score===0 && count($jt)>0) {
        $overlap=count(array_intersect($p['tokens'],$jt));
        $score=min(100,$overlap*8);
    }
    $reasons=[];
    if ($skillHits) $reasons[]='مهارات متطابقة: '.implode('، ',$skillHits);
    if ($p['qualification'] && mb_strpos($jobText,$p['qualification'])!==false) $reasons[]='المؤهل متوافق';
    if (!$reasons) $reasons[]='مطابقة أولية تحتاج إلى مراجعة';
    return ['score'=>(float)$score,'reasons'=>$reasons,'skills'=>$p['skills'],'qualification'=>$p['qualification']];
}
function ai_routes(PDO $db,string $method,string $path,array $user): bool {
    if ($method==='POST' && $path==='/api/v1/ai/analyze-profile') {
        if (empty($user['id'])) { json_response(['error'=>'Unauthorized'],401); return true; }
        $body=json_decode(file_get_contents('php://input'),true)?:[];
        $profile=$body['profile']??$body;
        if (!is_array($profile)) { json_response(['error'=>'Invalid profile'],422); return true; }
        $a=ai_extract_profile($profile);
        $stmt=$db->prepare("INSERT INTO ai_profile_analyses(user_id,skills_json,qualifications_json,summary,model_name,confidence)
                            VALUES(?,?,?,?,?,?)");
        $stmt->execute([$user['id'],json_encode($a['skills'],JSON_UNESCAPED_UNICODE),
            json_encode([$a['qualification']],JSON_UNESCAPED_UNICODE),
            'تحليل آلي أولي قابل للمراجعة','rule-based-v1',0.60]);
        json_response(['success'=>true,'analysis'=>$a,'notice'=>'هذه مطابقة آلية مساعدة وليست قراراً توظيفياً']); return true;
    }
    if ($method==='GET' && $path==='/api/v1/ai/job-matches') {
        if (empty($user['id'])) { json_response(['error'=>'Unauthorized'],401); return true; }
        $limit=min(50,max(1,(int)($_GET['limit']??20)));
        // Candidate profile data is intentionally assembled from available non-sensitive profile fields.
        $profile=[];
        try {
            $q=$db->prepare("SELECT * FROM candidate_profiles WHERE user_id=? LIMIT 1"); $q->execute([$user['id']]);
            $profile=$q->fetch(PDO::FETCH_ASSOC)?:[];
        } catch(Throwable $e){}
        $jobs=$db->query("SELECT * FROM jobs WHERE status='published' ORDER BY id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
        $out=[];
        foreach($jobs as $job){
            $m=ai_job_score($profile,$job);
            $out[]=['job_id'=>(int)$job['id'],'score'=>$m['score'],'reasons'=>$m['reasons'],'title'=>$job['title']??''];
            $chk=$db->prepare('SELECT id FROM ai_job_matches WHERE user_id=? AND job_id=? LIMIT 1');
            $chk->execute([$user['id'],$job['id']]); $mid=$chk->fetchColumn();
            $reasonJson=json_encode($m['reasons'],JSON_UNESCAPED_UNICODE);
            if($mid!==false){$db->prepare('UPDATE ai_job_matches SET score=?,reasons_json=?,created_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$m['score'],$reasonJson,$mid]);}
            else{$db->prepare('INSERT INTO ai_job_matches(user_id,job_id,score,reasons_json) VALUES(?,?,?,?)')->execute([$user['id'],$job['id'],$m['score'],$reasonJson]);}
        }
        usort($out,fn($a,$b)=>$b['score']<=>$a['score']);
        json_response(['matches'=>array_slice($out,0,$limit)]); return true;
    }
    return false;
}
