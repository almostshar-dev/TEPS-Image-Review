<?php
function public_services_routes(PDO $db, string $method, string $path, ?array $body, ?int $userId): ?array {
    if ($path === '/api/public-services' && $method === 'GET') {
        $stmt=$db->query("SELECT s.id,s.name,s.description,s.fee,c.name category FROM public_services s JOIN public_service_categories c ON c.id=s.category_id WHERE s.status='approved' ORDER BY s.id DESC");
        return ['status'=>200,'data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)];
    }
    if ($path === '/api/service-requests' && $method === 'GET') {
        if (!$userId) return ['status'=>401,'error'=>'يلزم تسجيل الدخول'];
        $stmt=$db->prepare('SELECT r.*,s.name service_name FROM service_requests r JOIN public_services s ON s.id=r.service_id WHERE r.user_id=? ORDER BY r.id DESC');$stmt->execute([$userId]);
        return ['status'=>200,'data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)];
    }
    if ($path === '/api/service-requests' && $method === 'POST') {
        if (!$userId) return ['status'=>401,'error'=>'يلزم تسجيل الدخول'];
        $serviceId=(int)($body['service_id']??0);$notes=trim((string)($body['notes']??''));
        $s=$db->prepare("SELECT * FROM public_services WHERE id=? AND status='approved'");$s->execute([$serviceId]);$service=$s->fetch(PDO::FETCH_ASSOC);if(!$service)return ['status'=>404,'error'=>'الخدمة غير متاحة'];
        $no='TEPS-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
        $st=$db->prepare('INSERT INTO service_requests(user_id,service_id,request_no,status,notes,fee) VALUES(?,?,?,?,?,?)');$st->execute([$userId,$serviceId,$no,'submitted',$notes,(float)$service['fee']]);
        $id=(int)$db->lastInsertId();$ev=$db->prepare('INSERT INTO service_request_events(request_id,status,note,created_by) VALUES(?,?,?,?)');$ev->execute([$id,'submitted','تم استلام الطلب',$userId]);
        return ['status'=>201,'message'=>'تم تقديم الطلب بنجاح','request_no'=>$no,'id'=>$id,'fee'=>(float)$service['fee']];
    }
    if (preg_match('#^/api/service-requests/(\d+)$#',$path,$m) && $method==='GET') {
        if (!$userId)return ['status'=>401,'error'=>'يلزم تسجيل الدخول'];$st=$db->prepare('SELECT r.*,s.name service_name FROM service_requests r JOIN public_services s ON s.id=r.service_id WHERE r.id=? AND r.user_id=?');$st->execute([(int)$m[1],$userId]);$r=$st->fetch(PDO::FETCH_ASSOC);if(!$r)return ['status'=>404,'error'=>'الطلب غير موجود'];$e=$db->prepare('SELECT status,note,created_at FROM service_request_events WHERE request_id=? ORDER BY id');$e->execute([$r['id']]);$r['timeline']=$e->fetchAll(PDO::FETCH_ASSOC);return ['status'=>200,'data'=>$r];
    }
    return null;
}
