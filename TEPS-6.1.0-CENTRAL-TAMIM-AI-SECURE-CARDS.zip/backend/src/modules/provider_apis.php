<?php
declare(strict_types=1);

/** Admin-managed provider API switches. Secrets are encrypted at rest and never returned by list endpoints. */
function provider_api_services(): array {
    return [
        'payment'=>['name'=>'الدفع الإلكتروني','description'=>'تفعيل الربط الآلي مع مزود الدفع مع إبقاء الإيصال اليدوي كخطة احتياطية.'],
        'sms'=>['name'=>'الرسائل النصية SMS','description'=>'إرسال OTP والتنبيهات عبر مزود رسمي.'],
        'email'=>['name'=>'البريد الإلكتروني','description'=>'إرسال الرسائل والتنبيهات البريدية.'],
        'maps'=>['name'=>'الخرائط والمواقع','description'=>'ربط الخرائط والمواقع الجغرافية.'],
        'ai'=>['name'=>'الذكاء الاصطناعي','description'=>'ربط مزود AI رسمي للمطابقة والتوصيات.'],
    ];
}
function provider_api_encrypt(?string $v): ?string { if($v===null||$v==='') return null; return prod_secret_encrypt($v); }
function provider_api_decrypt(?string $v): ?string { if($v===null||$v==='') return null; try{return prod_secret_decrypt($v);}catch(Throwable $e){return null;} }
function provider_api_field_definitions(string $service,string $provider): array {
    $common = [
      ['key'=>'api_base_url','label'=>'رابط API الأساسي (Base URL)','type'=>'url','required'=>true,'secret'=>false,'placeholder'=>'https://api.provider.example'],
      ['key'=>'api_key','label'=>'API Key / Public Key','type'=>'password','required'=>true,'secret'=>true],
      ['key'=>'api_secret','label'=>'API Secret / Private Key','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'client_id','label'=>'Client ID','type'=>'text','required'=>false,'secret'=>false],
      ['key'=>'client_secret','label'=>'Client Secret','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'merchant_id','label'=>'Merchant ID / رقم التاجر','type'=>'text','required'=>false,'secret'=>true],
      ['key'=>'terminal_id','label'=>'Terminal ID / رقم نقطة البيع','type'=>'text','required'=>false],
      ['key'=>'account_id','label'=>'Account ID / رقم الحساب','type'=>'text','required'=>false],
      ['key'=>'username','label'=>'اسم المستخدم API','type'=>'text','required'=>false],
      ['key'=>'password','label'=>'كلمة مرور API','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'access_token','label'=>'Access Token','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'webhook_url','label'=>'Webhook URL (يعرضه النظام للمزود)','type'=>'text','required'=>false,'secret'=>false,'readonly'=>true],
      ['key'=>'webhook_secret','label'=>'Webhook Secret / توقيع الاستدعاءات','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'signing_key','label'=>'Signing Key / مفتاح التوقيع','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'environment','label'=>'بيئة الربط','type'=>'select','required'=>true,'options'=>[['value'=>'sandbox','label'=>'Sandbox / تجريبية'],['value'=>'production','label'=>'Production / إنتاجية']]],
    ];
    if($service==='payment') return array_merge($common,[
      ['key'=>'merchant_name','label'=>'اسم التاجر المسجل لدى المزود','type'=>'text','required'=>false],
      ['key'=>'merchant_phone','label'=>'هاتف التاجر المسجل','type'=>'text','required'=>false],
      ['key'=>'currency','label'=>'العملة','type'=>'select','required'=>true,'options'=>[['value'=>'YER','label'=>'YER - ريال يمني'],['value'=>'SAR','label'=>'SAR - ريال سعودي'],['value'=>'USD','label'=>'USD - دولار']]],
      ['key'=>'country_code','label'=>'رمز الدولة','type'=>'text','required'=>false,'placeholder'=>'+967'],
      ['key'=>'payment_method_code','label'=>'رمز وسيلة الدفع لدى المزود','type'=>'text','required'=>false],
      ['key'=>'create_payment_endpoint','label'=>'مسار إنشاء عملية الدفع','type'=>'text','required'=>false,'placeholder'=>'/payments/create'],
      ['key'=>'status_endpoint','label'=>'مسار التحقق من حالة الدفع','type'=>'text','required'=>false,'placeholder'=>'/payments/{id}'],
      ['key'=>'refund_endpoint','label'=>'مسار الاسترداد Refund','type'=>'text','required'=>false],
      ['key'=>'callback_endpoint','label'=>'مسار Callback/Return','type'=>'text','required'=>false],
      ['key'=>'ip_whitelist','label'=>'عناوين IP المسموح بها (اختياري)','type'=>'textarea','required'=>false],
    ]);
    if($service==='sms') return array_merge($common,[
      ['key'=>'sender_id','label'=>'Sender ID / اسم المرسل','type'=>'text','required'=>true],
      ['key'=>'sms_endpoint','label'=>'مسار إرسال الرسائل','type'=>'text','required'=>false,'placeholder'=>'/sms/send'],
      ['key'=>'balance_endpoint','label'=>'مسار الاستعلام عن الرصيد','type'=>'text','required'=>false],
      ['key'=>'country_code','label'=>'رمز الدولة الافتراضي','type'=>'text','required'=>false,'placeholder'=>'+967'],
      ['key'=>'message_param','label'=>'اسم حقل نص الرسالة في API','type'=>'text','required'=>false,'placeholder'=>'message'],
      ['key'=>'phone_param','label'=>'اسم حقل رقم الهاتف في API','type'=>'text','required'=>false,'placeholder'=>'to'],
    ]);
    if($service==='email') return [
      ['key'=>'smtp_host','label'=>'SMTP Host','type'=>'text','required'=>true,'placeholder'=>'smtp.example.com'],
      ['key'=>'smtp_port','label'=>'SMTP Port','type'=>'number','required'=>true,'placeholder'=>'587'],
      ['key'=>'smtp_encryption','label'=>'التشفير','type'=>'select','required'=>true,'options'=>[['value'=>'tls','label'=>'TLS'],['value'=>'ssl','label'=>'SSL'],['value'=>'none','label'=>'بدون تشفير']]],
      ['key'=>'smtp_username','label'=>'SMTP Username','type'=>'text','required'=>true],
      ['key'=>'smtp_password','label'=>'SMTP Password','type'=>'password','required'=>true,'secret'=>true],
      ['key'=>'from_email','label'=>'البريد المرسل From Email','type'=>'email','required'=>true],
      ['key'=>'from_name','label'=>'اسم المرسل From Name','type'=>'text','required'=>true],
      ['key'=>'reply_to','label'=>'Reply-To','type'=>'email','required'=>false],
      ['key'=>'api_base_url','label'=>'رابط API البريد (إن وجد)','type'=>'url','required'=>false],
      ['key'=>'api_key','label'=>'API Key (إن وجد)','type'=>'password','required'=>false,'secret'=>true],
    ];
    if($service==='maps') return [
      ['key'=>'api_base_url','label'=>'رابط API الأساسي','type'=>'url','required'=>false],
      ['key'=>'api_key','label'=>'Maps API Key','type'=>'password','required'=>true,'secret'=>true],
      ['key'=>'project_id','label'=>'Project ID','type'=>'text','required'=>false],
      ['key'=>'client_id','label'=>'Client ID','type'=>'text','required'=>false],
      ['key'=>'client_secret','label'=>'Client Secret','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'map_id','label'=>'Map ID (اختياري)','type'=>'text','required'=>false],
      ['key'=>'region','label'=>'المنطقة الافتراضية','type'=>'text','required'=>false,'placeholder'=>'YE'],
      ['key'=>'language','label'=>'لغة نتائج الخرائط','type'=>'text','required'=>false,'placeholder'=>'ar'],
    ];
    return [
      ['key'=>'api_base_url','label'=>'رابط API الأساسي','type'=>'url','required'=>true],
      ['key'=>'api_key','label'=>'API Key','type'=>'password','required'=>true,'secret'=>true],
      ['key'=>'api_secret','label'=>'API Secret','type'=>'password','required'=>false,'secret'=>true],
      ['key'=>'model','label'=>'اسم النموذج Model','type'=>'text','required'=>true,'placeholder'=>'اسم النموذج الذي يوفره المزود'],
      ['key'=>'organization_id','label'=>'Organization / Project ID','type'=>'text','required'=>false],
      ['key'=>'request_endpoint','label'=>'مسار الطلبات','type'=>'text','required'=>false,'placeholder'=>'/v1/chat/completions'],
      ['key'=>'max_tokens','label'=>'الحد الأقصى للرموز','type'=>'number','required'=>false],
    ];
}
function provider_api_migrate(PDO $db): void {
    $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME)); $names=[];
    if($driver==='mysql'){ $rows=$db->query('SHOW COLUMNS FROM provider_api_configs')->fetchAll(PDO::FETCH_ASSOC); foreach($rows as $c)$names[$c['Field']]=true; if(!isset($names['credentials_json_enc']))$db->exec('ALTER TABLE provider_api_configs ADD COLUMN credentials_json_enc LONGTEXT NULL'); }
    else { $rows=$db->query('PRAGMA table_info(provider_api_configs)')->fetchAll(PDO::FETCH_ASSOC); foreach($rows as $c)$names[$c['name']]=true; if(!isset($names['credentials_json_enc']))$db->exec('ALTER TABLE provider_api_configs ADD COLUMN credentials_json_enc TEXT'); }
}
function provider_api_credentials(PDO $db,int $id): array {
    $st=$db->prepare('SELECT api_base_url,api_key_enc,api_secret_enc,merchant_id_enc,webhook_secret_enc,credentials_json_enc FROM provider_api_configs WHERE id=?');$st->execute([$id]);$r=$st->fetch(); if(!$r)return [];
    $d=[]; if(!empty($r['credentials_json_enc'])){ $raw=provider_api_decrypt($r['credentials_json_enc']); $j=json_decode($raw?:'{}',true); if(is_array($j))$d=$j; }
    if(!isset($d['api_base_url']) && !empty($r['api_base_url']))$d['api_base_url']=$r['api_base_url'];
    foreach(['api_key_enc'=>'api_key','api_secret_enc'=>'api_secret','merchant_id_enc'=>'merchant_id','webhook_secret_enc'=>'webhook_secret'] as $col=>$key){ if(!isset($d[$key]) && !empty($r[$col])){ $v=provider_api_decrypt($r[$col]); if($v!==null)$d[$key]=$v; } }
    return $d;
}
function provider_api_list(PDO $db, ?string $service=null): array {
    provider_api_migrate($db);
    $sql='SELECT id,service_code,provider_key,provider_name_ar,provider_name_en,api_base_url,mode,is_enabled,last_tested_at,last_test_status,last_test_message,created_at,updated_at FROM provider_api_configs';
    $args=[]; if($service){$sql.=' WHERE service_code=?';$args[]=$service;} $sql.=' ORDER BY service_code,id';
    $st=$db->prepare($sql);$st->execute($args);$rows=$st->fetchAll(); foreach($rows as &$row){ $row['fields']=provider_api_field_definitions($row['service_code'],$row['provider_key']); $vals=provider_api_credentials($db,(int)$row['id']); foreach($row['fields'] as $f){ if(!empty($f['secret']) && isset($vals[$f['key']])) $vals[$f['key']]='__configured__'; } $row['credentials']=$vals; } unset($row); return $rows;
}
function provider_api_upsert(PDO $db,array $d): array {
    provider_api_migrate($db);
    $service=trim((string)($d['service_code']??'')); $key=trim((string)($d['provider_key']??'')); $name=trim((string)($d['provider_name_ar']??''));
    if($service===''||$key===''||$name==='') throw new InvalidArgumentException('الخدمة والمزود والاسم العربي مطلوبة.');
    if(!isset(provider_api_services()[$service])) throw new InvalidArgumentException('الخدمة غير مدعومة حالياً.');
    $mode=$d['mode']??'manual'; if(!in_array($mode,['manual','api','sandbox'],true)) throw new InvalidArgumentException('وضع الربط غير صالح.');
    $credentials=is_array($d['credentials']??null)?$d['credentials']:[]; foreach(provider_api_field_definitions($service,$key) as $f){ if(isset($credentials[$f['key']])) $credentials[$f['key']]=(string)$credentials[$f['key']]; } $credEnc=$credentials?provider_api_encrypt(json_encode($credentials,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)):null;
    $id=(int)($d['id']??0);
    if($id){
        $st=$db->prepare('UPDATE provider_api_configs SET provider_name_ar=?,provider_name_en=?,api_base_url=?,mode=?,is_enabled=?,updated_at=CURRENT_TIMESTAMP'.
            ',api_key_enc=COALESCE(?,api_key_enc),api_secret_enc=COALESCE(?,api_secret_enc),merchant_id_enc=COALESCE(?,merchant_id_enc),webhook_secret_enc=COALESCE(?,webhook_secret_enc),credentials_json_enc=COALESCE(?,credentials_json_enc) WHERE id=?');
        $st->execute([$name,$d['provider_name_en']??null,$d['api_base_url']??null,$mode,(int)!empty($d['is_enabled']),provider_api_encrypt($d['api_key']??null),provider_api_encrypt($d['api_secret']??null),provider_api_encrypt($d['merchant_id']??null),provider_api_encrypt($d['webhook_secret']??null),$credEnc,$id]);
    } else {
        $st=$db->prepare('INSERT INTO provider_api_configs(service_code,provider_key,provider_name_ar,provider_name_en,api_base_url,api_key_enc,api_secret_enc,merchant_id_enc,webhook_secret_enc,credentials_json_enc,mode,is_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
        $st->execute([$service,$key,$name,$d['provider_name_en']??null,$d['api_base_url']??null,provider_api_encrypt($d['api_key']??null),provider_api_encrypt($d['api_secret']??null),provider_api_encrypt($d['merchant_id']??null),provider_api_encrypt($d['webhook_secret']??null),$credEnc,$mode,(int)!empty($d['is_enabled'])]); $id=(int)$db->lastInsertId();
    }
    return $db->query('SELECT id,service_code,provider_key,provider_name_ar,provider_name_en,api_base_url,mode,is_enabled,last_tested_at,last_test_status,last_test_message,created_at,updated_at FROM provider_api_configs WHERE id='.(int)$id)->fetch() ?: [];
}
function provider_api_toggle(PDO $db,int $id,bool $enabled,string $mode='api'): array {
    provider_api_migrate($db);
    if($enabled){ $missing=provider_api_missing_required($db,$id); if($missing) throw new InvalidArgumentException('لا يمكن التفعيل قبل استكمال الحقول: '.implode('، ',$missing)); }
    if(!in_array($mode,['manual','api','sandbox'],true)) $mode='api';
    $st=$db->prepare('UPDATE provider_api_configs SET is_enabled=?,mode=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$st->execute([(int)$enabled,$mode,$id]);
    if($st->rowCount()===0) throw new RuntimeException('المزود غير موجود.');
    return $db->query('SELECT id,service_code,provider_key,provider_name_ar,provider_name_en,api_base_url,mode,is_enabled,last_tested_at,last_test_status,last_test_message FROM provider_api_configs WHERE id='.(int)$id)->fetch() ?: [];
}
function provider_api_missing_required(PDO $db,int $id): array {
    $st=$db->prepare('SELECT service_code,provider_key FROM provider_api_configs WHERE id=?');$st->execute([$id]);$r=$st->fetch();if(!$r)return ['المزود غير موجود'];
    $values=provider_api_credentials($db,$id); $defs=provider_api_field_definitions($r['service_code'],$r['provider_key']); $missing=[];
    foreach($defs as $f){ if(!empty($f['required']) && trim((string)($values[$f['key']]??''))==='') $missing[]=$f['label']; } return $missing;
}
function provider_api_test(PDO $db,int $id): array {
    provider_api_migrate($db);
    $st=$db->prepare('SELECT * FROM provider_api_configs WHERE id=?');$st->execute([$id]);$r=$st->fetch();if(!$r)throw new RuntimeException('المزود غير موجود.');
    $missing=provider_api_missing_required($db,$id); $hasKey=!empty($r['api_key_enc']) || !empty(provider_api_credentials($db,$id)['api_key']); $hasUrl=!empty($r['api_base_url']) || !empty(provider_api_credentials($db,$id)['api_base_url']);
    $ok=!$missing && $hasKey && $hasUrl;
    $msg=$ok?'تم استكمال الحقول المطلوبة والتحقق من إعدادات الربط. لم يتم إرسال طلب خارجي تلقائياً حتى يتم تركيب Adapter رسمي للمزود.':'الحقول الناقصة: '.implode('، ',$missing);
    $status=$ok?'configured':'incomplete';
    $db->prepare('UPDATE provider_api_configs SET last_tested_at=CURRENT_TIMESTAMP,last_test_status=?,last_test_message=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$status,$msg,$id]);
    return ['ok'=>$ok,'status'=>$status,'message'=>$msg];
}
