<?php
declare(strict_types=1);

function teps_data_io_configs(): array {
    return [
        'governorates'=>['title'=>'المحافظات اليمنية','table'=>'yemen_governorates','columns'=>['id','code','name_ar','name_en','capital_ar','is_active']],
        'districts'=>['title'=>'المديريات','table'=>'yemen_districts','columns'=>['id','code','governorate_id','name_ar','name_en','latitude','longitude','is_active']],
        'entities'=>['title'=>'الجهات والمؤسسات اليمنية','table'=>'yemen_entities','columns'=>['id','entity_type','name_ar','name_en','governorate_id','district_id','address','phone','email','website','description','services','benefits','sector','status','source_name','source_url','source_record_id']],
        'universities'=>['title'=>'الجامعات والكليات والمعاهد','table'=>'educational_institutions','columns'=>['id','name_ar','name_en','institution_type','governorate','district','address','logo_path','description','verification_status']],
        'medical_facilities'=>['title'=>'المستشفيات والمراكز والعيادات','table'=>'medical_facilities','columns'=>['id','name_ar','name_en','facility_type','governorate','district','address','phone','description','verification_status']],
        'doctors'=>['title'=>'الأطباء والأخصائيون','table'=>'doctors','columns'=>['id','facility_id','name_ar','title','specialty_id','phone','bio','verification_status']],
        'companies'=>['title'=>'الشركات والمؤسسات','table'=>'companies','columns'=>['id','owner_id','name','business_type','governorate','district','address','description','verification_status']],
        'hotels'=>['title'=>'الفنادق','table'=>'hotels','columns'=>['id','name_ar','name_en','governorate','district','address','phone','description','stars','verification_status']],
        'restaurants'=>['title'=>'المطاعم','table'=>'restaurants','columns'=>['id','name_ar','name_en','governorate','district','address','phone','opening_hours','description','verification_status']],
        'favorites'=>['title'=>'المفضلة','table'=>'favorites','columns'=>['id','user_id','item_type','item_id','title_snapshot','created_at']],
        'jobs'=>['title'=>'الوظائف','table'=>'jobs','columns'=>['id','employer_id','title','description','governorate','district','work_type','qualification','salary_min','salary_max','status','created_at']],
        'external_jobs'=>['title'=>'الوظائف الخارجية','table'=>'external_job_posts','columns'=>['id','source_id','source_post_id','source_url','title','description','employer_name','country_id','governorate','district','discovered_at','status','contact_name','contact_phone','contact_email']],
        'education_windows'=>['title'=>'مواعيد التسجيل والتعليم','table'=>'education_registration_windows','columns'=>['id','institution_entity_id','title','registration_type','starts_at','ends_at','requirements','fees','status']],
        'medical_bookings'=>['title'=>'الحجوزات الطبية','table'=>'medical_appointments','columns'=>['id','doctor_id','patient_id','appointment_date','appointment_time','status','notes','created_at']],
        'hotel_bookings'=>['title'=>'حجوزات الفنادق','table'=>'hotel_bookings','columns'=>['id','hotel_id','room_id','user_id','check_in','check_out','guests','status','total_amount','created_at']],
        'restaurant_bookings'=>['title'=>'حجوزات المطاعم','table'=>'restaurant_bookings','columns'=>['id','restaurant_id','user_id','booking_date','booking_time','guests','status']],
        'service_bookings'=>['title'=>'الحجوزات الموحدة','table'=>'service_bookings','columns'=>['id','user_id','entity_id','booking_type','customer_name','customer_phone','booking_date','booking_time','quantity','service_name','notes','status','confirmation_code','created_at']],
        'social_links'=>['title'=>'التواصل الاجتماعي والتواصل مع الإدارة','table'=>'social_links','columns'=>['id','platform','label_ar','url','phone','is_header_visible','is_sidebar_visible','sort_order']],
        'terms'=>['title'=>'شروط الاستخدام والخصوصية','table'=>'platform_terms','columns'=>['id','version','terms_text','privacy_text','effective_at','is_active']],
        'referrals'=>['title'=>'الإحالات والعمولات','table'=>'referral_cases','columns'=>['id','external_job_id','applicant_user_id','admin_user_id','employer_contact_status','applicant_sent_status','commission_amount','commission_currency','commission_status','notes','created_at']],
        'notifications'=>['title'=>'الإشعارات','table'=>'notifications','columns'=>['id','user_id','title','body','type','is_read','created_at']],
    ];
}
function teps_data_io_route(PDO $db,string $method,string $path): bool {
    if(str_starts_with($path,'/api/admin/data/')) {
        $u=prod_require_user($db,['admin']);
        $cfgs=teps_data_io_configs();
        if(preg_match('#^/api/admin/data/([A-Za-z0-9_-]+)/export$#',$path,$m)&&$method==='GET'){
            $key=$m[1]; if(!isset($cfgs[$key])) json_response(['error'=>'القسم غير معروف'],404);
            $c=$cfgs[$key]; $cols=implode(',',array_map(fn($x)=>'`'.$x.'`',$c['columns']));
            $sql='SELECT '.$cols.' FROM `'.$c['table'].'` ORDER BY `id` DESC LIMIT 10000';
            $rows=$db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            header('Content-Type: text/csv; charset=UTF-8'); header('Content-Disposition: attachment; filename="TEPS-'.$key.'-'.date('Ymd-His').'.csv"');
            echo "\xEF\xBB\xBF".implode(',',array_map('teps_csv_cell',$c['columns']))."\r\n";
            foreach($rows as $row) echo implode(',',array_map(fn($col)=>teps_csv_cell($row[$col]??''),$c['columns']))."\r\n";
            exit;
        }
        if(preg_match('#^/api/admin/data/([A-Za-z0-9_-]+)/import$#',$path,$m)&&$method==='POST'){
            $key=$m[1]; if(!isset($cfgs[$key])) json_response(['error'=>'القسم غير معروف'],404);
            $f=$_FILES['file']??[]; if(($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) json_response(['error'=>'ملف CSV مطلوب'],422);
            if(($f['size']??0)>5*1024*1024) json_response(['error'=>'حجم ملف الاستيراد يتجاوز 5MB'],422);
            $h=fopen($f['tmp_name'],'rb'); if(!$h) json_response(['error'=>'تعذر قراءة الملف'],422); $header=fgetcsv($h); if(!$header){fclose($h);json_response(['error'=>'الملف فارغ'],422);}
            if(isset($header[0])) $header[0]=preg_replace('/^\xEF\xBB\xBF/','',$header[0]);
            $c=$cfgs[$key]; $allowed=array_flip($c['columns']); $cols=[]; foreach($header as $v){$v=trim((string)$v);if(isset($allowed[$v]))$cols[]=$v;}
            if(!$cols) {fclose($h);json_response(['error'=>'عناوين الأعمدة غير صالحة لهذا القسم'],422);}
            $count=0;$errors=[];$db->beginTransaction();
            try {
                while(($row=fgetcsv($h))!==false){$vals=[];foreach($header as $i=>$col){if(isset($allowed[$col]))$vals[$col]=trim((string)($row[$i]??''));}if(!$vals)continue;
                    if(isset($vals['id']) && ctype_digit((string)$vals['id'])){
                        $id=(int)$vals['id'];$set=array_values(array_filter($cols,fn($x)=>$x!=='id'));if($set){$sql='UPDATE `'.$c['table'].'` SET '.implode(',',array_map(fn($x)=>'`'.$x.'`=?',$set)).' WHERE id=?';$st=$db->prepare($sql);$st->execute(array_merge(array_map(fn($x)=>$vals[$x]??null,$set),[$id]));}
                    } else {
                        $insertCols=array_values(array_filter($cols,fn($x)=>$x!=='id'));$sql='INSERT INTO `'.$c['table'].'` (`'.implode('`,`',$insertCols).'`) VALUES ('.implode(',',array_fill(0,count($insertCols),'?')).')';$st=$db->prepare($sql);$st->execute(array_map(fn($x)=>$vals[$x]??null,$insertCols));
                    } $count++;
                }
                $db->commit(); fclose($h); audit($db,(int)$u['id'],'data_import','table',null,['section'=>$key,'count'=>$count]); json_response(['ok'=>true,'message'=>'تم الاستيراد بنجاح','count'=>$count]);
            } catch(Throwable $e){if($db->inTransaction())$db->rollBack();fclose($h);json_response(['error'=>'فشل الاستيراد: '.$e->getMessage()],422);}
        }
        if(preg_match('#^/api/admin/data/([A-Za-z0-9_-]+)/print$#',$path,$m)&&$method==='GET'){
            $key=$m[1]; if(!isset($cfgs[$key])) json_response(['error'=>'القسم غير معروف'],404); json_response(['ok'=>true,'section'=>$key,'print'=>'استخدم وظيفة طباعة المتصفح للجدول المعروض.']);
        }
        if($path==='/api/admin/data/catalog'&&$method==='GET') json_response(['data'=>array_map(fn($k,$v)=>['key'=>$k,'title'=>$v['title'],'table'=>$v['table'],'columns'=>$v['columns']],array_keys($cfgs),$cfgs)]);
    }
    return false;
}
function teps_csv_cell($v): string { $v=(string)$v; return '"'.str_replace('"','""',str_replace(["\r","\n"],[" "," "],$v)).'"'; }
