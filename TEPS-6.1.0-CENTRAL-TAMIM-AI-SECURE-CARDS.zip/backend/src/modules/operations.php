<?php
declare(strict_types=1);

function operations_health(PDO $db): array {
    $checks=[];
    $run=function(string $name, callable $fn) use (&$checks,$db): void {
        try { $details=$fn(); $status='ok'; }
        catch(Throwable $e){ $details=$e->getMessage(); $status='error'; }
        $checks[]=['name'=>$name,'status'=>$status,'details'=>$details];
        try { $s=$db->prepare('INSERT INTO system_health_checks(check_name,status,details) VALUES(?,?,?)'); $s->execute([$name,$status,is_scalar($details)?(string)$details:json_encode($details,JSON_UNESCAPED_UNICODE)]); } catch(Throwable $ignore) {}
    };
    $run('database',fn()=>['driver'=>$db->getAttribute(PDO::ATTR_DRIVER_NAME),'users'=>(int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn()]);
    $run('schema',function() use($db){$driver=$db->getAttribute(PDO::ATTR_DRIVER_NAME);$sql=$driver==='mysql'?"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()":"SELECT COUNT(*) FROM sqlite_master WHERE type='table'";return ['tables'=>(int)$db->query($sql)->fetchColumn(),'driver'=>$driver];});
    $run('storage',fn()=>['writable'=>is_writable(dirname(__DIR__,2).'/storage')]);
    $overall=empty(array_filter($checks,fn($c)=>$c['status']!=='ok'));
    return ['ok'=>$overall,'checked_at'=>date('c'),'checks'=>$checks];
}

function operations_backup(PDO $db): array {
    $root=dirname(__DIR__,2);
    $dir=$root.'/storage/backups';
    if(!is_dir($dir) && !mkdir($dir,0750,true) && !is_dir($dir)) throw new RuntimeException('تعذر إنشاء مجلد النسخ الاحتياطي');
    $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME));
    $stamp=date('Ymd-His').'-'.bin2hex(random_bytes(3));
    if($driver==='sqlite'){
        $file=$dir.'/teps-'.$stamp.'.sqlite'; $safe=str_replace("'","''",$file);
        try{$db->exec("VACUUM INTO '$safe'");$size=(int)filesize($file);$hash=hash_file('sha256',$file);$s=$db->prepare('INSERT INTO backup_runs(backup_path,file_size,sha256,status) VALUES(?,?,?,?)');$s->execute([str_replace($root.'/','',$file),$size,$hash,'completed']);return ['status'=>'completed','driver'=>'sqlite','path'=>str_replace($root.'/','',$file),'file_size'=>$size,'sha256'=>$hash];}
        catch(Throwable $e){if(is_file($file))@unlink($file);throw $e;}
    }
    if($driver==='mysql'){
        $host=prod_env('TAMIM_DB_HOST','127.0.0.1');$port=prod_env('TAMIM_DB_PORT','3306');$name=prod_env('TAMIM_DB_NAME','tamim');$user=prod_env('TAMIM_DB_USER','tamim');$pass=prod_env('TAMIM_DB_PASS','');$dump=prod_env('TAMIM_MYSQLDUMP_BIN','mysqldump');$file=$dir.'/teps-'.$stamp.'.sql';
        $cmd=escapeshellcmd($dump).' --single-transaction --routines --triggers -h '.escapeshellarg($host).' -P '.escapeshellarg($port).' -u '.escapeshellarg($user).' '.escapeshellarg($name).' > '.escapeshellarg($file);
        $env='MYSQL_PWD='.escapeshellarg($pass);$output=[];$code=0;exec($env.' '.$cmd.' 2>&1',$output,$code);
        if($code!==0){if(is_file($file))@unlink($file);throw new RuntimeException('تعذر إنشاء نسخة MySQL: '.implode(' ',array_slice($output,-3)));}
        $size=(int)filesize($file);$hash=hash_file('sha256',$file);$s=$db->prepare('INSERT INTO backup_runs(backup_path,file_size,sha256,status) VALUES(?,?,?,?)');$s->execute([str_replace($root.'/','',$file),$size,$hash,'completed']);return ['status'=>'completed','driver'=>'mysql','path'=>str_replace($root.'/','',$file),'file_size'=>$size,'sha256'=>$hash];
    }
    throw new RuntimeException('قاعدة البيانات غير مدعومة للنسخ الاحتياطي');
}
