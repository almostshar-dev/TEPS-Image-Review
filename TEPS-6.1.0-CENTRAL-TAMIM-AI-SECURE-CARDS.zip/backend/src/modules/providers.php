<?php
declare(strict_types=1);
/** Provider abstraction: credentials are intentionally externalized to environment variables. */
function provider_email(PDO $db,?int $uid,string $to,string $subject,string $body): int { return prod_queue($db,$uid,'email',$to,$subject,$body); }
function provider_sms(PDO $db,?int $uid,string $to,string $body): int { return prod_queue($db,$uid,'sms',$to,null,$body); }
function provider_push(PDO $db,?int $uid,string $body,array $payload=[]): int { return prod_queue($db,$uid,'push',null,null,$body,$payload); }
function provider_process_outbox(PDO $db,int $limit=50): array {
    $rows=$db->query("SELECT * FROM notification_outbox WHERE status='pending' AND available_at<=CURRENT_TIMESTAMP ORDER BY id LIMIT ".max(1,$limit))->fetchAll();$done=0;$failed=0;
    foreach($rows as $r){
        try {
            $channel=$r['channel'];
            $enabled=(bool)prod_env('TAMIM_'.strtoupper($channel).'_ENABLED','0');
            if(!$enabled) throw new RuntimeException('مزود '.$channel.' غير مفعل؛ تم إبقاء الرسالة في سجل الانتظار.');
            // Official provider adapters belong here. No fake delivery is reported as successful.
            throw new RuntimeException('لم يتم تركيب Adapter خارجي لهذا المزود بعد.');
        } catch(Throwable $e) { $db->prepare('UPDATE notification_outbox SET attempts=attempts+1,last_error=?,available_at=DATE_ADD(UTC_TIMESTAMP(), INTERVAL 10 MINUTE) WHERE id=?')->execute([$e->getMessage(),$r['id']]);$failed++; }
    }
    return ['processed'=>$done,'failed'=>$failed,'pending'=>count($rows)-$done];
}
