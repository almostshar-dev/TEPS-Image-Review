<?php
declare(strict_types=1);
/** Stage 19 — external integrations and social publishing queue. */
function integration_routes(PDO $db,string $method,string $path,array $user): bool {
    $admin=(($user['role']??'')==='admin');
    if (str_starts_with($path,'/api/v1/integrations/') && !$admin) { json_response(['error'=>'Forbidden'],403); return true; }

    if($method==='GET' && $path==='/api/v1/integrations/list'){
        $rows=$db->query("SELECT id,name,provider,category,enabled,created_at,updated_at FROM integrations ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
        json_response(['integrations'=>$rows]); return true;
    }
    if($method==='POST' && $path==='/api/v1/integrations'){
        $b=json_decode(file_get_contents('php://input'),true)?:[];
        if(trim((string)($b['name']??''))==='' || trim((string)($b['provider']??''))===''){json_response(['error'=>'name and provider required'],422);return true;}
        $q=$db->prepare("INSERT INTO integrations(name,provider,category,config_json,enabled) VALUES(?,?,?,?,?)");
        $q->execute([$b['name'],$b['provider'],$b['category']??'other',isset($b['config'])?json_encode($b['config'],JSON_UNESCAPED_UNICODE):null,(int)($b['enabled']??0)]);
        json_response(['success'=>true,'id'=>(int)$db->lastInsertId()],201); return true;
    }
    if($method==='POST' && $path==='/api/v1/integrations/social/queue'){
        $b=json_decode(file_get_contents('php://input'),true)?:[];
        $platform=$b['platform']??'';
        $allowed=['facebook','telegram','whatsapp','linkedin','x'];
        if(!in_array($platform,$allowed,true)){json_response(['error'=>'Unsupported platform'],422);return true;}
        $q=$db->prepare("INSERT INTO social_publish_queue(content_type,content_id,platform,title,body,media_url,scheduled_at) VALUES(?,?,?,?,?,?,?)");
        $q->execute([$b['content_type']??'job',$b['content_id']??null,$platform,$b['title']??null,$b['body']??null,$b['media_url']??null,$b['scheduled_at']??null]);
        json_response(['success'=>true,'id'=>(int)$db->lastInsertId(),'status'=>'pending'],201); return true;
    }
    if($method==='GET' && $path==='/api/v1/integrations/social/queue'){
        $rows=$db->query("SELECT * FROM social_publish_queue ORDER BY COALESCE(scheduled_at,created_at) DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
        json_response(['queue'=>$rows]); return true;
    }
    if($method==='POST' && preg_match('#^/api/v1/integrations/social/queue/(\d+)/review$#',$path,$m)){
        $b=json_decode(file_get_contents('php://input'),true)?:[]; $status=$b['status']??'approved';
        if(!in_array($status,['approved','rejected','cancelled'],true)){json_response(['error'=>'Invalid status'],422);return true;}
        $q=$db->prepare("UPDATE social_publish_queue SET status=? WHERE id=?"); $q->execute([$status,(int)$m[1]]);
        json_response(['success'=>true]); return true;
    }
    if($method==='POST' && $path==='/api/v1/integrations/social/process'){
        $rows=$db->query("SELECT * FROM social_publish_queue WHERE status='approved' AND (scheduled_at IS NULL OR scheduled_at<=CURRENT_TIMESTAMP) AND attempts<3 ORDER BY id LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
        // Actual provider calls are intentionally not faked. Marking is left to provider adapters.
        json_response(['ready'=>$rows,'count'=>count($rows),'notice'=>'Provider adapters must perform the actual API publish call.']); return true;
    }
    return false;
}
