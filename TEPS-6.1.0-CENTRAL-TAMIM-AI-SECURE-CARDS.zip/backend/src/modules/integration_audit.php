<?php
declare(strict_types=1);

function platform_integration_audit(PDO $db): array {
    $root=dirname(__DIR__,2);
    $requiredTables=['users','profiles','jobs','job_applications','advertisements','advertisement_stats','notifications','conversations','messages','invoices','payments','educational_institutions','medical_facilities','doctors','hotels','hotel_bookings','events','event_bookings','celebrities','celebrity_bookings','public_services','service_requests','referrals','reviews','complaints','analytics_events','ai_job_matches','external_jobs','integrations','security_audit_logs','system_health_checks','backup_runs','system_alerts'];
    $tables=[]; $driver=strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME)); $allTables=$driver==='mysql' ? $db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE()")->fetchAll(PDO::FETCH_COLUMN) : $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN); $set=array_fill_keys($allTables,true);
    foreach($requiredTables as $t) $tables[$t]=isset($set[$t]);
    $files=[
      'schema_registry'=>'src/schema_registry.php','operations'=>'src/modules/operations.php','integration_audit'=>'src/modules/integration_audit.php',
      'security'=>'src/modules/security.php','index'=>'public/index.php'
    ];
    foreach($files as $k=>$rel) $files[$k]=['path'=>$rel,'exists'=>is_file($root.'/'.$rel)];
    $index=(string)file_get_contents($root.'/public/index.php');
    $routes=[
      'health'=>'/api/v1/health','backup'=>'/api/v1/admin/backup','integration_audit'=>'/api/v1/admin/integration-audit','ads'=>'/api/v1/ads'
    ];
    foreach($routes as $k=>$needle) $routes[$k]=['path'=>$needle,'wired'=>str_contains($index,$needle)];
    $missingTables=array_keys(array_filter($tables,fn($v)=>!$v));
    $missingFiles=array_keys(array_filter($files,fn($v)=>!$v['exists']));
    $missingRoutes=array_keys(array_filter($routes,fn($v)=>!$v['wired']));
    return ['ok'=>!$missingTables&&!$missingFiles&&!$missingRoutes,'tables'=>$tables,'files'=>$files,'routes'=>$routes,'missing'=>['tables'=>$missingTables,'files'=>$missingFiles,'routes'=>$missingRoutes],'checked_at'=>date('c')];
}
