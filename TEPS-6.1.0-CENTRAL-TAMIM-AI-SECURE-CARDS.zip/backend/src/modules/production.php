<?php
declare(strict_types=1);

function prod_env(string $key, ?string $default=null): ?string { $v=getenv($key); return ($v===false||$v==='')?$default:$v; }
function prod_now(): string { return gmdate('Y-m-d H:i:s'); }
function prod_hash_token(string $token): string { return hash('sha256',$token); }
function prod_issue_session(PDO $db,int $userId): string {
    $token=rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'),'=');
    $hash=prod_hash_token($token); $days=max(1,(int)prod_env('TAMIM_SESSION_DAYS','30'));
    $exp=gmdate('Y-m-d H:i:s',time()+$days*86400);
    $st=$db->prepare('INSERT INTO auth_sessions(user_id,token_hash,ip_address,user_agent,device_name,expires_at) VALUES(?,?,?,?,?,?)');
    $st->execute([$userId,$hash,$_SERVER['REMOTE_ADDR']??null,$_SERVER['HTTP_USER_AGENT']??null,$_SERVER['HTTP_X_DEVICE_NAME']??null,$exp]);
    return $token;
}
function prod_revoke_session(PDO $db,string $token): void { $st=$db->prepare('UPDATE auth_sessions SET revoked_at=? WHERE token_hash=?');$st->execute([prod_now(),prod_hash_token($token)]); }
function prod_auth_user(PDO $db): ?array {
    $token=bearer_token(); if(!$token)return null;
    $hash=prod_hash_token($token);
    $st=$db->prepare('SELECT u.*,p.full_name,p.verified_status,p.gender,p.nationality,p.birth_place,p.birth_date,p.id_type,p.id_number,p.id_issue_date,p.primary_phone,p.alternate_phone FROM auth_sessions s JOIN users u ON u.id=s.user_id JOIN profiles p ON p.user_id=u.id WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.status="active" LIMIT 1');
    $st->execute([$hash,prod_now()]); $u=$st->fetch();
    if($u){$db->prepare('UPDATE auth_sessions SET last_seen_at=? WHERE token_hash=?')->execute([prod_now(),$hash]);unset($u['api_token'],$u['password_hash']);return $u;}
    return auth_user($db);
}
function prod_require_user(PDO $db,array $roles=[]): array { $u=prod_auth_user($db); if(!$u)json_response(['error'=>'غير مصرح. سجل الدخول أولاً.'],401); if($roles&&!in_array($u['role'],$roles,true))json_response(['error'=>'ليس لديك صلاحية لهذا الإجراء.'],403); return $u; }
function prod_issue_reset(PDO $db,int $userId): string {
    $raw=bin2hex(random_bytes(32));$hash=prod_hash_token($raw);$exp=gmdate('Y-m-d H:i:s',time()+3600);
    $db->prepare('UPDATE password_reset_tokens SET used_at=? WHERE user_id=? AND used_at IS NULL')->execute([prod_now(),$userId]);
    $db->prepare('INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES(?,?,?)')->execute([$userId,$hash,$exp]); return $raw;
}
function prod_verify_reset(PDO $db,string $raw): ?int { $st=$db->prepare('SELECT user_id FROM password_reset_tokens WHERE token_hash=? AND used_at IS NULL AND expires_at > ? LIMIT 1');$st->execute([prod_hash_token($raw),prod_now()]);$id=$st->fetchColumn();return $id===false?null:(int)$id; }
function prod_mark_reset_used(PDO $db,string $raw): void {$db->prepare('UPDATE password_reset_tokens SET used_at=? WHERE token_hash=?')->execute([prod_now(),prod_hash_token($raw)]);}
function prod_queue(PDO $db,?int $uid,string $channel,?string $dest,string $subject,string $body,array $payload=[]): int { $st=$db->prepare('INSERT INTO notification_outbox(user_id,channel,destination,subject,body,payload_json) VALUES(?,?,?,?,?,?)');$st->execute([$uid,$channel,$dest,$subject,$body,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);return (int)$db->lastInsertId(); }
function prod_generate_otp(PDO $db,?int $uid,string $channel,string $destination,string $purpose='verify'): string { $code=(string)random_int(100000,999999);$hash=prod_hash_token($code);$exp=gmdate('Y-m-d H:i:s',time()+600);$db->prepare('UPDATE otp_codes SET used_at=? WHERE destination=? AND purpose=? AND used_at IS NULL')->execute([prod_now(),$destination,$purpose]);$db->prepare('INSERT INTO otp_codes(user_id,channel,destination,code_hash,purpose,expires_at) VALUES(?,?,?,?,?,?)')->execute([$uid,$channel,$destination,$hash,$purpose,$exp]);return $code; }
function prod_verify_otp(PDO $db,string $destination,string $purpose,string $code): bool { $st=$db->prepare('SELECT id,attempts FROM otp_codes WHERE destination=? AND purpose=? AND used_at IS NULL AND expires_at > ? ORDER BY id DESC LIMIT 1');$st->execute([$destination,$purpose,prod_now()]);$r=$st->fetch();if(!$r||((int)$r['attempts']>=5))return false;if(!hash_equals((string)$db->query('SELECT code_hash FROM otp_codes WHERE id='.(int)$r['id'])->fetchColumn(),prod_hash_token($code))){$db->prepare('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?')->execute([(int)$r['id']]);return false;}$db->prepare('UPDATE otp_codes SET used_at=? WHERE id=?')->execute([prod_now(),(int)$r['id']]);return true; }
function prod_secret_encrypt(string $plain): string { $key=hash('sha256',(string)prod_env('TAMIM_ENCRYPTION_KEY','CHANGE_ME'),true);$iv=random_bytes(16);$ct=openssl_encrypt($plain,'AES-256-CBC',$key,OPENSSL_RAW_DATA,$iv);if($ct===false)throw new RuntimeException('تعذر تشفير السر');return base64_encode($iv.$ct); }
function prod_secret_decrypt(string $enc): string { $raw=base64_decode($enc,true);if($raw===false||strlen($raw)<17)throw new RuntimeException('سر مشفر غير صالح');$key=hash('sha256',(string)prod_env('TAMIM_ENCRYPTION_KEY','CHANGE_ME'),true);$v=openssl_decrypt(substr($raw,16),'AES-256-CBC',$key,OPENSSL_RAW_DATA,substr($raw,0,16));if($v===false)throw new RuntimeException('تعذر فك السر');return $v; }
