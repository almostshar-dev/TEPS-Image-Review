<?php
declare(strict_types=1);

/** Stage 21 — security helpers and production hardening. */
function security_apply_headers(): void {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    header('Content-Security-Policy: default-src \'self\'; img-src \'self\' data: https:; style-src \'self\' \'unsafe-inline\'; script-src \'self\' \'unsafe-inline\'; connect-src \'self\' https:; frame-ancestors \'none\';');
}
function security_cors(): void {
    $origin=$_SERVER['HTTP_ORIGIN']??'';
    $allowed=getenv('TAMIM_ALLOWED_ORIGINS') ?: '';
    $list=array_filter(array_map('trim',explode(',',$allowed)));
    if($origin && in_array($origin,$list,true)){
        header('Access-Control-Allow-Origin: '.$origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Credentials: true');
    }
    header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept, X-CSRF-Token');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
}
function security_csrf_token(): string {
    if(session_status()!==PHP_SESSION_ACTIVE) @session_start();
    if(empty($_SESSION['csrf_token'])) $_SESSION['csrf_token']=bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function security_require_csrf(): bool {
    if(in_array($_SERVER['REQUEST_METHOD']??'GET',['GET','HEAD','OPTIONS'],true)) return true;
    $token=$_SERVER['HTTP_X_CSRF_TOKEN']??'';
    return $token!=='' && isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'],$token);
}
function security_password_policy(string $password): bool {
    return strlen($password)>=8 && preg_match('/[A-Za-z]/',$password) && preg_match('/\d/',$password);
}
function security_safe_filename(string $name): string {
    $name=preg_replace('/[^A-Za-z0-9._-]/','_',basename($name));
    return substr($name,0,120);
}
function security_rate_key(): string {
    return hash('sha256',($_SERVER['REMOTE_ADDR']??'unknown').'|'.($_SERVER['REQUEST_URI']??''));
}
function security_rate_limit(int $max=120,int $window=60): bool {
    $dir=__DIR__.'/../../storage/rate';
    if(!is_dir($dir)) @mkdir($dir,0750,true);
    $f=$dir.'/'.security_rate_key().'.json';
    $now=time(); $data=['start'=>$now,'count'=>0];
    if(is_file($f)) $data=json_decode((string)file_get_contents($f),true)?:$data;
    if($now-(int)$data['start'] >= $window) $data=['start'=>$now,'count'=>0];
    $data['count']++;
    @file_put_contents($f,json_encode($data),LOCK_EX);
    return $data['count'] <= $max;
}
