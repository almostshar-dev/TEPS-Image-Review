<?php
declare(strict_types=1);

function admin_accounts_api(PDO $db,string $path,string $method): bool {
    if($path==='/api/admin/admin-accounts' && $method==='GET'){
        require_user($db,['admin']);
        $rows=$db->query("SELECT u.id,u.phone,u.email,u.role,u.status,u.created_at,p.full_name FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.role='admin' ORDER BY u.id DESC")->fetchAll();
        json_response(['data'=>$rows]);
    }
    if($path==='/api/admin/admin-accounts' && $method==='POST'){
        $actor=require_user($db,['admin']); $d=request_json();
        $name=trim((string)($d['full_name']??'')); $phone=trim((string)($d['phone']??'')); $email=trim((string)($d['email']??'')); $pass=(string)($d['password']??'');
        if($name===''||$phone===''||strlen($pass)<8) json_response(['error'=>'اسم المدير ورقم الهاتف وكلمة المرور (8 أحرف على الأقل) مطلوبة'],422);
        $q=$db->prepare('SELECT id FROM users WHERE phone=? OR (email IS NOT NULL AND email=? ) LIMIT 1'); $q->execute([$phone,$email?:null]);
        if($q->fetchColumn()!==false) json_response(['error'=>'رقم الهاتف أو البريد مستخدم بالفعل.'],409);
        try{
            $db->beginTransaction();
            $token=bin2hex(random_bytes(32));
            $st=$db->prepare('INSERT INTO users(phone,email,password_hash,role,status,phone_serial,api_token) VALUES(?,?,?,?,?,?,?)');
            $st->execute([$phone,$email?:null,password_hash($pass,PASSWORD_DEFAULT),'admin','active','TEPS-ADMIN-'.strtoupper(bin2hex(random_bytes(4))),$token]);
            $uid=(int)$db->lastInsertId();
            $st=$db->prepare('INSERT INTO profiles(user_id,full_name,language,verified_status,primary_phone) VALUES(?,?,?,?,?)');
            $st->execute([$uid,$name,'ar','approved',$phone]);
            $db->commit();
            audit($db,(int)$actor['id'],'admin_account_created','user',$uid,['role'=>'admin']);
            json_response(['message'=>'تم إنشاء حساب المدير بنجاح.','id'=>$uid],201);
        }catch(Throwable $e){ if($db->inTransaction())$db->rollBack(); json_response(['error'=>'تعذر إنشاء حساب المدير.'],500); }
    }
    return false;
}
