<?php
declare(strict_types=1);
function secure_file_path(string $relative): string { $base=realpath(dirname(__DIR__).'/storage/uploads');$candidate=realpath(dirname(__DIR__).'/storage/'.$relative);if(!$base||!$candidate||strpos($candidate,$base.DIRECTORY_SEPARATOR)!==0)throw new RuntimeException('مسار ملف غير صالح');return $candidate; }
function serve_private_file(PDO $db,array $u,string $kind,int $id): never {
    if($kind==='identity'){$st=$db->prepare('SELECT d.*,d.user_id owner_id FROM identity_documents d WHERE d.id=?');$st->execute([$id]);$d=$st->fetch();if(!$d)json_response(['error'=>'الملف غير موجود'],404);if($u['role']!=='admin'&&(int)$d['owner_id']!==(int)$u['id'])json_response(['error'=>'لا تملك صلاحية الوصول'],403);}
    elseif($kind==='payment_receipt'){$st=$db->prepare('SELECT pr.*,p.user_id owner_id FROM payment_receipts pr JOIN payments p ON p.id=pr.payment_id WHERE pr.payment_id=?');$st->execute([$id]);$d=$st->fetch();if(!$d)json_response(['error'=>'الإيصال غير موجود'],404);if($u['role']!=='admin'&&(int)$d['owner_id']!==(int)$u['id'])json_response(['error'=>'لا تملك صلاحية الوصول'],403);}
    elseif($kind==='business'){$st=$db->prepare('SELECT d.*,e.user_id owner_id FROM business_documents d JOIN employer_profiles e ON e.id=d.employer_id WHERE d.id=?');$st->execute([$id]);$d=$st->fetch();if(!$d)json_response(['error'=>'الملف غير موجود'],404);if($u['role']!=='admin'&&(int)$d['owner_id']!==(int)$u['id'])json_response(['error'=>'لا تملك صلاحية الوصول'],403);}
    else json_response(['error'=>'نوع الملف غير مدعوم'],400);
    try{$path=secure_file_path($d['file_path']);}catch(Throwable $e){json_response(['error'=>'الملف غير متاح'],404);}header('Content-Type: '.($d['mime_type']?:'application/octet-stream'));header('Content-Length: '.filesize($path));header('Content-Disposition: inline; filename="'.security_safe_filename((string)($d['original_name']?:basename($path))).'"');readfile($path);exit;
}
