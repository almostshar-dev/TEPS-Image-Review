<?php
declare(strict_types=1);

/**
 * Stage 16: analytics & reports.
 * Aggregates existing platform tables and optional analytics_events.
 */
function analytics_routes(PDO $db, string $method, string $path, array $user): bool {
    if ($method === 'POST' && $path === '/api/v1/analytics/event') {
        $allowed = ['page_view','job_view','job_apply','ad_view','ad_click','booking','payment','signup','login','search','referral'];
        $body = json_decode(file_get_contents('php://input'), true) ?: [];
        $type = trim((string)($body['event_type'] ?? ''));
        if (!in_array($type, $allowed, true)) {
            json_response(['error'=>'Invalid event_type'], 422); return true;
        }
        $stmt=$db->prepare("INSERT INTO analytics_events
            (event_type,entity_type,entity_id,user_id,session_id,value_num,metadata_json)
            VALUES(?,?,?,?,?,?,?)");
        $stmt->execute([
            $type, $body['entity_type'] ?? null, $body['entity_id'] ?? null,
            $user['id'] ?? null, $body['session_id'] ?? null,
            isset($body['value']) ? (float)$body['value'] : null,
            isset($body['metadata']) ? json_encode($body['metadata'], JSON_UNESCAPED_UNICODE) : null
        ]);
        json_response(['success'=>true]); return true;
    }

    if ($method === 'GET' && $path === '/api/v1/analytics/summary') {
        if (($user['role'] ?? '') !== 'admin') { json_response(['error'=>'Forbidden'],403); return true; }
        $from=$_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
        $to=$_GET['to'] ?? date('Y-m-d');
        $summary=[];
        $summary['users'] = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $summary['jobs'] = (int)$db->query("SELECT COUNT(*) FROM jobs")->fetchColumn();
        $summary['applications'] = (int)$db->query("SELECT COUNT(*) FROM job_applications")->fetchColumn();
        foreach ([
            'visitors'=>'visitors','advertisements'=>'advertisements','payments'=>'payments',
            'subscriptions'=>'subscriptions','referrals'=>'referrals','reviews'=>'reviews','complaints'=>'complaints'
        ] as $key=>$table) {
            try { $summary[$key]=(int)$db->query("SELECT COUNT(*) FROM $table")->fetchColumn(); }
            catch(Throwable $e) { $summary[$key]=0; }
        }
        try {
            $q=$db->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE created_at BETWEEN ? AND ?");
            $q->execute([$from.' 00:00:00',$to.' 23:59:59']);
            $summary['revenue']=(float)$q->fetchColumn();
        } catch(Throwable $e) { $summary['revenue']=0; }

        $q=$db->prepare("SELECT DATE(created_at) day,event_type,COUNT(*) cnt
                         FROM analytics_events WHERE DATE(created_at) BETWEEN ? AND ?
                         GROUP BY DATE(created_at),event_type ORDER BY day");
        $q->execute([$from,$to]);
        $summary['events']=$q->fetchAll(PDO::FETCH_ASSOC);
        $summary['range']=['from'=>$from,'to'=>$to];
        json_response($summary); return true;
    }

    if ($method === 'GET' && $path === '/api/v1/analytics/report') {
        if (($user['role'] ?? '') !== 'admin') { json_response(['error'=>'Forbidden'],403); return true; }
        $type=$_GET['type'] ?? 'overview';
        $from=$_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
        $to=$_GET['to'] ?? date('Y-m-d');
        $rows=[];
        switch($type){
            case 'jobs':
                $rows=$db->query("SELECT status,COUNT(*) count FROM jobs GROUP BY status")->fetchAll(PDO::FETCH_ASSOC); break;
            case 'applications':
                $rows=$db->query("SELECT status,COUNT(*) count FROM job_applications GROUP BY status")->fetchAll(PDO::FETCH_ASSOC); break;
            case 'ads':
                try {$rows=$db->query("SELECT ad_type,status,COUNT(*) count FROM advertisements GROUP BY ad_type,status")->fetchAll(PDO::FETCH_ASSOC);} catch(Throwable $e) {}
                break;
            case 'events':
                $q=$db->prepare("SELECT DATE(created_at) day,event_type,COUNT(*) count FROM analytics_events WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY DATE(created_at),event_type ORDER BY day,event_type");
                $q->execute([$from,$to]); $rows=$q->fetchAll(PDO::FETCH_ASSOC); break;
            case 'payments':
                try {
                    $q=$db->prepare("SELECT DATE(created_at) day,COALESCE(SUM(amount),0) total,COUNT(*) count FROM payments WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY day");
                    $q->execute([$from,$to]); $rows=$q->fetchAll(PDO::FETCH_ASSOC);
                } catch(Throwable $e) {}
                break;
            default:
                $rows=[[
                    'users'=>(int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
                    'jobs'=>(int)$db->query("SELECT COUNT(*) FROM jobs")->fetchColumn(),
                    'applications'=>(int)$db->query("SELECT COUNT(*) FROM job_applications")->fetchColumn()
                ]];
        }
        json_response(['type'=>$type,'from'=>$from,'to'=>$to,'rows'=>$rows]); return true;
    }
    return false;
}
