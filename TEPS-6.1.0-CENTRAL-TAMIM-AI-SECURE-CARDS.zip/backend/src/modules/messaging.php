<?php
declare(strict_types=1);
function create_notification(PDO $db,int $userId,string $type,string $title,string $body,array $data=[]): void { $s=$db->prepare('INSERT INTO notifications(user_id,type,title,body,data_json) VALUES(?,?,?,?,?)'); $s->execute([$userId,$type,$title,$body,json_encode($data,JSON_UNESCAPED_UNICODE)]); }
function messaging_enabled(PDO $db): bool { return (bool)$db->query('SELECT enabled FROM messaging_settings WHERE id=1')->fetchColumn(); }
function create_conversation(PDO $db,int $userId,int $otherUserId,string $subject=''): int { $db->beginTransaction(); $db->exec('INSERT INTO conversations(subject) VALUES('.$db->quote($subject).')'); $id=(int)$db->lastInsertId(); $s=$db->prepare('INSERT INTO conversation_members(conversation_id,user_id) VALUES(?,?),(?,?)'); $s->execute([$id,$userId,$id,$otherUserId]); $db->commit(); return $id; }
