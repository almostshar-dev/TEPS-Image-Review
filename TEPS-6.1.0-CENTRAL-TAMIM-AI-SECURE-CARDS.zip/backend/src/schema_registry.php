<?php
declare(strict_types=1);

/** Stage 23 — deterministic schema registry + compatibility normalization. */
function platform_schema_paths(string $root): array {
    return [
        $root.'/database/schema.sql',
        $root.'/database/finance.sql',
        $root.'/database/payment_receipts.sql',
        $root.'/database/payment_methods_admin.sql',
        $root.'/database/provider_apis.sql',
        $root.'/database/ads.sql',
        $root.'/database/messaging.sql',
        $root.'/database/education.sql',
        $root.'/database/medical.sql',
        $root.'/database/tourism.sql',
        $root.'/database/events.sql',
        $root.'/database/celebrities.sql',
        $root.'/database/public_services.sql',
        $root.'/database/referrals_reviews.sql',
        $root.'/database/rewards.sql',
        $root.'/database/licensing.sql',
        $root.'/database/analytics.sql',
        $root.'/database/ai.sql',
        $root.'/database/external_jobs.sql',
        $root.'/database/integrations.sql',
        $root.'/backend/database/security.sql',
        $root.'/backend/database/operations.sql',
        $root.'/backend/database/production.sql',
    ];
}

function sqlite_columns(PDO $db,string $table): array {
    $rows=$db->query('PRAGMA table_info("'.str_replace('"','""',$table).'")')->fetchAll(PDO::FETCH_ASSOC);
    $out=[]; foreach($rows as $r) $out[$r['name']]=true; return $out;
}

function normalize_platform_schema(PDO $db): void {
    // notifications: merge the legacy base columns with messaging columns.
    $cols=sqlite_columns($db,'notifications');
    if($cols && !isset($cols['type'])) $db->exec("ALTER TABLE notifications ADD COLUMN type TEXT NOT NULL DEFAULT 'general'");
    if($cols && !isset($cols['data_json'])) $db->exec("ALTER TABLE notifications ADD COLUMN data_json TEXT");
    if($cols && !isset($cols['read_at'])) $db->exec("ALTER TABLE notifications ADD COLUMN read_at TEXT");

    // advertisements: rebuild the legacy table once so all ad consumers share one contract.
    $cols=sqlite_columns($db,'advertisements');
    if($cols && !isset($cols['ad_type'])) {
        $db->exec('PRAGMA foreign_keys=OFF');
        $db->beginTransaction();
        try {
            $db->exec('ALTER TABLE advertisements RENAME TO advertisements_legacy');
            $db->exec("CREATE TABLE advertisements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                advertiser_user_id INTEGER NULL,
                title TEXT NOT NULL,
                description TEXT,
                image_url TEXT,
                target_url TEXT,
                ad_type TEXT NOT NULL DEFAULT 'normal',
                status TEXT NOT NULL DEFAULT 'pending',
                starts_at TEXT,
                ends_at TEXT,
                priority INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(advertiser_user_id) REFERENCES users(id)
            )");
            $db->exec("INSERT INTO advertisements(id,title,image_url,target_url,ad_type,status,starts_at,ends_at,created_at)
                       SELECT id,title,image_path,target_url,
                              CASE type WHEN 'urgent' THEN 'urgent_sponsored' WHEN 'sponsored' THEN 'sponsored' WHEN 'featured' THEN 'featured' ELSE 'normal' END,
                              status,starts_at,ends_at,created_at
                       FROM advertisements_legacy");
            $db->exec('DROP TABLE advertisements_legacy');
            $db->exec('CREATE INDEX IF NOT EXISTS idx_ads_status_type ON advertisements(status,ad_type)');
            $db->commit();
        } catch(Throwable $e) {
            if($db->inTransaction()) $db->rollBack();
            throw $e;
        } finally { $db->exec('PRAGMA foreign_keys=ON'); }
    }
}

function load_platform_schemas(PDO $db): array {
    $root=dirname(__DIR__,2);
    if(strtolower((string)$db->getAttribute(PDO::ATTR_DRIVER_NAME))==='mysql') return ['loaded'=>['mysql_schema.sql'],'missing'=>[]];
    $loaded=[]; $missing=[];
    foreach(platform_schema_paths($root) as $file) {
        if(!is_file($file)){ $missing[]=basename($file); continue; }
        $db->exec((string)file_get_contents($file));
        $loaded[]=basename($file);
        if(basename($file)==='schema.sql') normalize_platform_schema($db);
    }
    // Re-run normalization after all legacy CREATE TABLE IF NOT EXISTS statements.
    normalize_platform_schema($db);
    return ['loaded'=>$loaded,'missing'=>$missing];
}
