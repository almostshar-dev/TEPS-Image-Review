<?php
declare(strict_types=1);

/** TEPS environment loader - supports both TAMIM_* and legacy DB_* names. */
function tamim_set_env(string $key, string $value): void {
    if (function_exists('putenv')) { @putenv($key.'='.$value); }
    $_ENV[$key] = $value;
    $_SERVER[$key] = $value;
}

function tamim_load_env(string $file): void {
    if (!is_file($file) || !is_readable($file)) return;
    $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) return;
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '' || ($line[0] ?? '') === '#' || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $k = trim($k);
        $v = trim($v);
        if ($v !== '' && (($v[0] ?? '') === '"' || ($v[0] ?? '') === "'")) {
            $v = trim($v, "\"'");
        }
        if ($k !== '') tamim_set_env($k, $v);
    }
}

function tamim_env(string $key, ?string $default = null): ?string {
    $v = getenv($key);
    if ($v !== false) return (string)$v;
    if (isset($_ENV[$key])) return (string)$_ENV[$key];
    if (isset($_SERVER[$key])) return (string)$_SERVER[$key];
    return $default;
}

// htdocs/.env
$envFile = dirname(__DIR__, 2) . '/.env';
tamim_load_env($envFile);

// Backward compatibility with the DB_* names previously used in deployment files.
if (tamim_env('TAMIM_DB_DRIVER') === null || tamim_env('TAMIM_DB_DRIVER') === '') {
    $legacyHost = tamim_env('DB_HOST');
    if ($legacyHost !== null && $legacyHost !== '') tamim_set_env('TAMIM_DB_DRIVER', 'mysql');
}
if (tamim_env('TAMIM_DB_HOST') === null) tamim_set_env('TAMIM_DB_HOST', (string)(tamim_env('DB_HOST') ?? ''));
if (tamim_env('TAMIM_DB_PORT') === null) tamim_set_env('TAMIM_DB_PORT', (string)(tamim_env('DB_PORT', '3306') ?? '3306'));
if (tamim_env('TAMIM_DB_NAME') === null) tamim_set_env('TAMIM_DB_NAME', (string)(tamim_env('DB_DATABASE') ?? ''));
if (tamim_env('TAMIM_DB_USER') === null) tamim_set_env('TAMIM_DB_USER', (string)(tamim_env('DB_USERNAME') ?? ''));
if (tamim_env('TAMIM_DB_PASS') === null) tamim_set_env('TAMIM_DB_PASS', (string)(tamim_env('DB_PASSWORD') ?? ''));
