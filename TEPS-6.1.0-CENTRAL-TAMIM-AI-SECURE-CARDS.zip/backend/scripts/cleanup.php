<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/src/env.php';
require dirname(__DIR__).'/src/bootstrap.php';require dirname(__DIR__).'/src/modules/production.php';
$db->exec("DELETE FROM auth_sessions WHERE revoked_at IS NOT NULL OR datetime(expires_at)<=datetime('now')");
$db->exec("DELETE FROM password_reset_tokens WHERE used_at IS NOT NULL OR datetime(expires_at)<=datetime('now')");
$db->exec("DELETE FROM otp_codes WHERE used_at IS NOT NULL OR datetime(expires_at)<=datetime('now')");
echo "cleanup: OK\n";
