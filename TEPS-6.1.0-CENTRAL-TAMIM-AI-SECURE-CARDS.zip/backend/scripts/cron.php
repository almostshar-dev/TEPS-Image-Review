<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/src/env.php';
require dirname(__DIR__).'/src/bootstrap.php';
require_once dirname(__DIR__).'/src/modules/tamim_core.php';
teps_core_schema($db);require dirname(__DIR__).'/src/modules/production.php';require dirname(__DIR__).'/src/modules/providers.php';
provider_process_outbox($db,100); require_once dirname(__DIR__).'/src/modules/rewards.php'; $pending=$db->query("SELECT id FROM referrals WHERE status='pending'")->fetchAll(PDO::FETCH_COLUMN); foreach($pending as $rid){ try{rewards_grant_referral($db,(int)$rid);}catch(Throwable $e){} }
$db->exec("UPDATE system_jobs SET status='failed',error_message='انتهت مهلة القفل' WHERE status='running' AND locked_at IS NOT NULL AND datetime(locked_at,'+30 minutes')<=datetime('now')");
echo "cron: OK\n";
