<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/src/env.php';
require dirname(__DIR__).'/src/bootstrap.php';require dirname(__DIR__).'/src/modules/production.php';require dirname(__DIR__).'/src/modules/providers.php';
echo json_encode(provider_process_outbox($db,100),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT).PHP_EOL;
