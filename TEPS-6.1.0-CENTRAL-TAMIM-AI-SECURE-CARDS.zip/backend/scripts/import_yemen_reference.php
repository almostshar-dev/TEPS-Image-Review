<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/bootstrap.php';
if(PHP_SAPI!=='cli'){ $u=prod_require_user($db,['admin']); }
function fetch_json_url(string $url): array { $ctx=stream_context_create(['http'=>['timeout'=>30,'user_agent'=>'TEPS-Yemen-Reference/5.2']]);$raw=@file_get_contents($url,false,$ctx);if($raw===false)throw new RuntimeException('تعذر الوصول إلى المصدر: '.$url);$d=json_decode($raw,true);if(!is_array($d))throw new RuntimeException('استجابة المصدر غير صالحة');return $d; }
$govMap=[];$q=$db->query('SELECT id,code FROM yemen_governorates');foreach($q->fetchAll() as $r)$govMap[$r['code']]=(int)$r['id'];
$rows=fetch_json_url('https://raw.githubusercontent.com/open-admin-data/yemen-administrative-divisions/refs/heads/master/data/all-district.json');$count=0;$st=$db->prepare('INSERT INTO yemen_districts(code,governorate_id,name_ar,name_en,latitude,longitude) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE governorate_id=VALUES(governorate_id),name_ar=VALUES(name_ar),name_en=VALUES(name_en),latitude=VALUES(latitude),longitude=VALUES(longitude)');
foreach($rows as $r){$code=(string)($r['id']??'');$parent=(string)($r['parent']['id']??'');if(!$code||!isset($govMap[$parent]))continue;$st->execute([$code,$govMap[$parent],$r['name']['local']??'', $r['name']['en']??null,$r['geo']['lat']??null,$r['geo']['lon']??null]);$count++;}
$db->prepare("INSERT INTO yemen_reference_import_runs(source_key,status,imported_count,started_at,finished_at,message) VALUES('admin_divisions','success',?,NOW(),NOW(),'تم تحديث المديريات من المصدر')")->execute([$count]);echo json_encode(['ok'=>true,'imported'=>$count],JSON_UNESCAPED_UNICODE);
