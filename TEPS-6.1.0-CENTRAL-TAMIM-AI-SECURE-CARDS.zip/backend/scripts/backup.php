<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/src/env.php';
require __DIR__.'/../src/bootstrap.php';
require_once __DIR__.'/../src/modules/operations.php';
try { echo json_encode(operations_backup($db),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT).PHP_EOL; exit(0); }
catch(Throwable $e){ fwrite(STDERR,$e->getMessage().PHP_EOL); exit(1); }
