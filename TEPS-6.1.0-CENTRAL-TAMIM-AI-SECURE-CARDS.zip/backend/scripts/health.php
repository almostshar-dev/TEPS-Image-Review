<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/src/env.php';
require __DIR__.'/../src/bootstrap.php';
require_once __DIR__.'/../src/modules/operations.php';
$result=operations_health($db);
echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT).PHP_EOL;
exit($result['ok']?0:1);
